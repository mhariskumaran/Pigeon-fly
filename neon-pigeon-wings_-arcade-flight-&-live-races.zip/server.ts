import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { LeaderboardEntry, RacePlayer, RaceRoom, WSClientMessage, WSServerMessage } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory persistent database for player accounts & leaderboard
interface StoredUser {
  id: string;
  username: string;
  passwordHash: string; // simple demo password store
  token: string;
  coins: number;
  highScore: number;
  totalDistance: number;
  totalCoinsEarned: number;
  racesWon: number;
  racesPlayed: number;
  equippedSkin: string;
  unlockedSkins: string[];
  claimedSeasonTiers: number[];
  seasonPoints: number;
  completedQuests: string[];
  updatedAt: number;
}

const usersDb = new Map<string, StoredUser>(); // username.toLowerCase() -> StoredUser
const tokensDb = new Map<string, string>(); // token -> username.toLowerCase()

// Seed some initial competitive leaderboard pilots
const initialPilots: Array<{ username: string; highScore: number; coins: number; wins: number; skin: string }> = [
  { username: 'CyberWing_99', highScore: 4820, coins: 6420, wins: 28, skin: 'rainbow_prism' },
  { username: 'NeonFalcon', highScore: 3950, coins: 4800, wins: 19, skin: 'golden_mecha' },
  { username: 'RetroCoo', highScore: 3210, coins: 3650, wins: 14, skin: 'vaporwave_drip' },
  { username: 'PixelFeather', highScore: 2780, coins: 2900, wins: 11, skin: 'matrix_glider' },
  { username: 'AeroLaser', highScore: 2450, coins: 2150, wins: 8, skin: 'solar_phoenix' },
  { username: 'VortexPigeon', highScore: 1980, coins: 1800, wins: 5, skin: 'classic_cyber' },
];

initialPilots.forEach((pilot, i) => {
  const user: StoredUser = {
    id: `pilot_bot_${i}`,
    username: pilot.username,
    passwordHash: 'pass123',
    token: `token_bot_${i}`,
    coins: pilot.coins,
    highScore: pilot.highScore,
    totalDistance: pilot.highScore * 4,
    totalCoinsEarned: pilot.coins,
    racesWon: pilot.wins,
    racesPlayed: pilot.wins * 2,
    equippedSkin: pilot.skin,
    unlockedSkins: ['classic_cyber', pilot.skin],
    claimedSeasonTiers: [1, 2, 3],
    seasonPoints: pilot.wins * 120 + 300,
    completedQuests: ['q_coins_single', 'q_rings_single'],
    updatedAt: Date.now() - i * 3600000,
  };
  usersDb.set(pilot.username.toLowerCase(), user);
});

// REST API Endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', serverTime: Date.now(), activeUsers: usersDb.size });
});

// Auth endpoints
app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || typeof username !== 'string' || username.trim().length < 2) {
    res.status(400).json({ error: 'Username must be at least 2 characters' });
    return;
  }
  if (!password || typeof password !== 'string' || password.length < 3) {
    res.status(400).json({ error: 'Password must be at least 3 characters' });
    return;
  }

  const key = username.trim().toLowerCase();
  if (usersDb.has(key)) {
    res.status(409).json({ error: 'Pilot callsign already registered' });
    return;
  }

  const token = `tok_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const newUser: StoredUser = {
    id: `usr_${Date.now()}`,
    username: username.trim(),
    passwordHash: password,
    token,
    coins: 200,
    highScore: 0,
    totalDistance: 0,
    totalCoinsEarned: 200,
    racesWon: 0,
    racesPlayed: 0,
    equippedSkin: 'classic_cyber',
    unlockedSkins: ['classic_cyber'],
    claimedSeasonTiers: [],
    seasonPoints: 100,
    completedQuests: [],
    updatedAt: Date.now(),
  };

  usersDb.set(key, newUser);
  tokensDb.set(token, key);

  res.json({
    token,
    profile: {
      id: newUser.id,
      username: newUser.username,
      isGuest: false,
      coins: newUser.coins,
      highScore: newUser.highScore,
      totalDistance: newUser.totalDistance,
      totalCoinsEarned: newUser.totalCoinsEarned,
      racesWon: newUser.racesWon,
      racesPlayed: newUser.racesPlayed,
      equippedSkin: newUser.equippedSkin,
      unlockedSkins: newUser.unlockedSkins,
      claimedSeasonTiers: newUser.claimedSeasonTiers,
      seasonPoints: newUser.seasonPoints,
      completedQuests: newUser.completedQuests,
      createdAt: newUser.updatedAt,
    },
  });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password required' });
    return;
  }

  const key = username.trim().toLowerCase();
  const user = usersDb.get(key);
  if (!user || user.passwordHash !== password) {
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }

  const token = `tok_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  user.token = token;
  tokensDb.set(token, key);

  res.json({
    token,
    profile: {
      id: user.id,
      username: user.username,
      isGuest: false,
      coins: user.coins,
      highScore: user.highScore,
      totalDistance: user.totalDistance,
      totalCoinsEarned: user.totalCoinsEarned,
      racesWon: user.racesWon,
      racesPlayed: user.racesPlayed,
      equippedSkin: user.equippedSkin,
      unlockedSkins: user.unlockedSkins,
      claimedSeasonTiers: user.claimedSeasonTiers,
      seasonPoints: user.seasonPoints,
      completedQuests: user.completedQuests,
      createdAt: user.updatedAt,
    },
  });
});

app.post('/api/player/sync', (req, res) => {
  const authHeader = req.headers.authorization;
  const { profile } = req.body;
  if (!profile) {
    res.status(400).json({ error: 'Profile data required' });
    return;
  }

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    const userKey = tokensDb.get(token);
    if (userKey) {
      const user = usersDb.get(userKey);
      if (user) {
        user.coins = Math.max(0, profile.coins ?? user.coins);
        user.highScore = Math.max(user.highScore, profile.highScore ?? 0);
        user.totalDistance = Math.max(user.totalDistance, profile.totalDistance ?? 0);
        user.totalCoinsEarned = Math.max(user.totalCoinsEarned, profile.totalCoinsEarned ?? 0);
        user.racesWon = Math.max(user.racesWon, profile.racesWon ?? 0);
        user.racesPlayed = Math.max(user.racesPlayed, profile.racesPlayed ?? 0);
        user.equippedSkin = profile.equippedSkin || user.equippedSkin;
        user.unlockedSkins = Array.from(new Set([...user.unlockedSkins, ...(profile.unlockedSkins || [])]));
        user.claimedSeasonTiers = Array.from(new Set([...user.claimedSeasonTiers, ...(profile.claimedSeasonTiers || [])]));
        user.seasonPoints = Math.max(user.seasonPoints, profile.seasonPoints ?? 0);
        user.completedQuests = Array.from(new Set([...user.completedQuests, ...(profile.completedQuests || [])]));
        user.updatedAt = Date.now();
        res.json({ success: true, profile: user });
        return;
      }
    }
  }

  // If anonymous guest or token not found, update in leaderboard cache if valid
  res.json({ success: true, profile });
});

app.get('/api/leaderboard', (req, res) => {
  const list: LeaderboardEntry[] = [];
  usersDb.forEach((u) => {
    list.push({
      id: u.id,
      username: u.username,
      highScore: u.highScore,
      totalCoinsEarned: u.totalCoinsEarned,
      racesWon: u.racesWon,
      skin: u.equippedSkin,
      updatedAt: u.updatedAt,
    });
  });

  list.sort((a, b) => b.highScore - a.highScore);
  res.json({ leaderboard: list.slice(0, 50) });
});

// Setup HTTP and WebSocket Server
async function startServer() {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  // Multiplayer Rooms State
  const rooms = new Map<string, RaceRoom>();
  const clientRoomMap = new Map<WebSocket, { roomId: string; playerId: string }>();

  // Create default quick match room
  const defaultRoom: RaceRoom = {
    id: 'room_neon_prime',
    name: 'Neon Skyway Alpha',
    status: 'waiting',
    maxPlayers: 6,
    targetDistance: 1500,
    seed: 1337,
    countdown: 0,
    players: {},
    createdAt: Date.now(),
  };
  rooms.set(defaultRoom.id, defaultRoom);

  function broadcastToRoom(roomId: string, message: WSServerMessage) {
    const raw = JSON.stringify(message);
    clientRoomMap.forEach((meta, clientWs) => {
      if (meta.roomId === roomId && clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(raw);
      }
    });
  }

  function getPublicRoomsList(): RaceRoom[] {
    const list: RaceRoom[] = [];
    rooms.forEach((r) => list.push(r));
    return list;
  }

  function broadcastRoomList() {
    const list = getPublicRoomsList();
    const raw = JSON.stringify({ type: 'room_list', rooms: list } as WSServerMessage);
    clientRoomMap.forEach((_, clientWs) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(raw);
      }
    });
  }

  function startRoomCountdown(roomId: string) {
    const room = rooms.get(roomId);
    if (!room || room.status !== 'waiting') return;

    room.status = 'starting';
    room.countdown = 3;
    broadcastToRoom(roomId, { type: 'room_state', room });

    const timer = setInterval(() => {
      room.countdown -= 1;
      if (room.countdown > 0) {
        broadcastToRoom(roomId, { type: 'countdown', count: room.countdown });
      } else {
        clearInterval(timer);
        room.status = 'racing';
        room.seed = Math.floor(Math.random() * 100000);
        // Reset player positions
        Object.values(room.players).forEach((p) => {
          p.distance = 0;
          p.crashed = false;
          p.finished = false;
          p.finishTime = undefined;
        });
        broadcastToRoom(roomId, {
          type: 'race_start',
          seed: room.seed,
          targetDistance: room.targetDistance,
        });
        broadcastToRoom(roomId, { type: 'room_state', room });
        broadcastRoomList();
      }
    }, 1000);
  }

  wss.on('connection', (ws: WebSocket) => {
    let currentRoomId: string | null = null;
    let playerId: string = `p_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    let playerName: string = 'Pilot';
    let skin: string = 'classic_cyber';

    ws.send(JSON.stringify({
      type: 'welcome',
      playerId,
      rooms: getPublicRoomsList(),
    } as WSServerMessage));

    ws.on('message', (data: string) => {
      try {
        const msg = JSON.parse(data.toString()) as WSClientMessage;

        if (msg.type === 'join_lobby') {
          playerName = msg.username || playerName;
          skin = msg.skinId || skin;
          ws.send(JSON.stringify({ type: 'room_list', rooms: getPublicRoomsList() }));
        } 
        else if (msg.type === 'create_room') {
          const newRoomId = `room_${Date.now()}`;
          const newRoom: RaceRoom = {
            id: newRoomId,
            name: msg.roomName || `Room #${Math.floor(100 + Math.random() * 900)}`,
            status: 'waiting',
            maxPlayers: msg.maxPlayers || 4,
            targetDistance: 1500,
            seed: Math.floor(Math.random() * 10000),
            countdown: 0,
            players: {
              [playerId]: {
                id: playerId,
                username: playerName,
                skinId: skin,
                isReady: true,
                x: 100,
                y: 300,
                vy: 0,
                distance: 0,
                finished: false,
                crashed: false,
              },
            },
            createdAt: Date.now(),
          };
          rooms.set(newRoomId, newRoom);
          currentRoomId = newRoomId;
          clientRoomMap.set(ws, { roomId: newRoomId, playerId });

          ws.send(JSON.stringify({ type: 'room_state', room: newRoom }));
          broadcastRoomList();
        } 
        else if (msg.type === 'join_room') {
          const room = rooms.get(msg.roomId);
          if (!room) {
            ws.send(JSON.stringify({ type: 'error', message: 'Room not found' }));
            return;
          }
          if (Object.keys(room.players).length >= room.maxPlayers) {
            ws.send(JSON.stringify({ type: 'error', message: 'Room is full' }));
            return;
          }

          // Leave old room if any
          if (currentRoomId && rooms.has(currentRoomId)) {
            const oldRoom = rooms.get(currentRoomId)!;
            delete oldRoom.players[playerId];
            broadcastToRoom(currentRoomId, { type: 'room_state', room: oldRoom });
          }

          currentRoomId = room.id;
          clientRoomMap.set(ws, { roomId: room.id, playerId });

          room.players[playerId] = {
            id: playerId,
            username: playerName,
            skinId: skin,
            isReady: false,
            x: 100,
            y: 300,
            vy: 0,
            distance: 0,
            finished: false,
            crashed: false,
          };

          broadcastToRoom(room.id, { type: 'room_state', room });
          broadcastRoomList();
        } 
        else if (msg.type === 'toggle_ready') {
          if (!currentRoomId) return;
          const room = rooms.get(currentRoomId);
          if (!room || !room.players[playerId]) return;

          room.players[playerId].isReady = !room.players[playerId].isReady;
          broadcastToRoom(room.id, { type: 'room_state', room });

          // If all connected players are ready and count >= 1
          const playerList = Object.values(room.players);
          const allReady = playerList.length >= 1 && playerList.every((p) => p.isReady);
          if (allReady && room.status === 'waiting') {
            startRoomCountdown(room.id);
          }
        } 
        else if (msg.type === 'pilot_update') {
          if (!currentRoomId) return;
          const room = rooms.get(currentRoomId);
          if (!room || !room.players[playerId]) return;

          const p = room.players[playerId];
          p.distance = msg.distance;
          p.y = msg.y;
          p.vy = msg.vy;
          p.crashed = msg.crashed;

          // Broadcast delta to room
          broadcastToRoom(room.id, {
            type: 'pilot_sync',
            pilots: {
              [playerId]: {
                distance: p.distance,
                y: p.y,
                vy: p.vy,
                crashed: p.crashed,
              },
            },
          });
        } 
        else if (msg.type === 'finish_race') {
          if (!currentRoomId) return;
          const room = rooms.get(currentRoomId);
          if (!room || !room.players[playerId]) return;

          const p = room.players[playerId];
          if (!p.finished) {
            p.finished = true;
            p.finishTime = msg.finishTime || Date.now();
            if (!room.winnerId) {
              room.winnerId = playerId;
            }

            const allFinished = Object.values(room.players).every((pl) => pl.finished || pl.crashed);
            if (allFinished || room.winnerId) {
              const standings = Object.values(room.players).sort((a, b) => {
                if (a.finished && b.finished) return (a.finishTime || 0) - (b.finishTime || 0);
                if (a.finished) return -1;
                if (b.finished) return 1;
                return b.distance - a.distance;
              });

              standings.forEach((pl, idx) => {
                pl.rank = idx + 1;
              });

              room.status = 'finished';
              broadcastToRoom(room.id, {
                type: 'race_over',
                winnerId: room.winnerId,
                standings,
              });
              broadcastRoomList();
            }
          }
        } 
        else if (msg.type === 'send_chat') {
          if (!currentRoomId) return;
          broadcastToRoom(currentRoomId, {
            type: 'chat_broadcast',
            sender: playerName,
            message: msg.message.slice(0, 80),
            timestamp: Date.now(),
          });
        }
      } catch (err) {
        console.error('WS error:', err);
      }
    });

    ws.on('close', () => {
      clientRoomMap.delete(ws);
      if (currentRoomId && rooms.has(currentRoomId)) {
        const room = rooms.get(currentRoomId)!;
        delete room.players[playerId];
        // If empty and not default, cleanup
        if (Object.keys(room.players).length === 0 && room.id !== 'room_neon_prime') {
          rooms.delete(currentRoomId);
        } else {
          broadcastToRoom(currentRoomId, { type: 'room_state', room });
        }
        broadcastRoomList();
      }
    });
  });

  // Vite middleware in dev, static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (WebSocket on /ws)`);
  });
}

startServer();
