/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { FlightGameView } from './components/FlightGameView';
import { CompeteView } from './components/CompeteView';
import { ShopView } from './components/ShopView';
import { QuestsView } from './components/QuestsView';
import { LeaderboardView } from './components/LeaderboardView';
import { AuthModal } from './components/AuthModal';
import { UserProfile } from './types';
import { createDefaultProfile } from './game/constants';
import { sounds } from './audio/chiptune';

const STORAGE_PROFILE_KEY = 'neon_pigeon_profile_v1';
const STORAGE_TOKEN_KEY = 'neon_pigeon_token_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<'flight' | 'compete' | 'shop' | 'quests' | 'leaderboard'>('flight');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [authToken, setAuthToken] = useState<string | null>(null);

  // User Profile
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PROFILE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to parse stored profile', e);
    }
    return createDefaultProfile();
  });

  // Load saved token on mount
  useEffect(() => {
    try {
      const savedToken = localStorage.getItem(STORAGE_TOKEN_KEY);
      if (savedToken) {
        setAuthToken(savedToken);
      }
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, []);

  // Save profile to localStorage and sync to cloud server
  const saveAndSyncProfile = useCallback((updated: UserProfile, token: string | null) => {
    try {
      localStorage.setItem(STORAGE_PROFILE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Local storage write error', e);
    }

    // Push to backend
    fetch('/api/player/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ profile: updated }),
    }).catch((err) => console.warn('Sync failed:', err));
  }, []);

  const handleUpdateProfile = useCallback(
    (updates: Partial<UserProfile>) => {
      setProfile((prev) => {
        const next = { ...prev, ...updates };
        saveAndSyncProfile(next, authToken);
        return next;
      });
    },
    [authToken, saveAndSyncProfile]
  );

  const handleLoginSuccess = (token: string, newProfile: UserProfile) => {
    setAuthToken(token);
    try {
      localStorage.setItem(STORAGE_TOKEN_KEY, token);
    } catch (e) {}
    setProfile(newProfile);
    saveAndSyncProfile(newProfile, token);
  };

  const handleUpdateCallsign = (newName: string) => {
    handleUpdateProfile({ username: newName });
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sounds.setMuted(nextMuted);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex flex-col font-display selection:bg-cyan-500 selection:text-black">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        profile={profile}
        isMuted={isMuted}
        toggleMute={handleToggleMute}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full px-3 sm:px-6 py-4 sm:py-6 flex flex-col items-center">
        {activeTab === 'flight' && (
          <FlightGameView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onGoToShop={() => setActiveTab('shop')}
            onGoToCompete={() => setActiveTab('compete')}
          />
        )}

        {activeTab === 'compete' && (
          <CompeteView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'shop' && (
          <ShopView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onStartFlight={() => setActiveTab('flight')}
          />
        )}

        {activeTab === 'quests' && (
          <QuestsView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            profile={profile}
          />
        )}
      </main>

      {/* Account Authentication & Callsign Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        profile={profile}
        onLoginSuccess={handleLoginSuccess}
        onUpdateCallsign={handleUpdateCallsign}
      />
    </div>
  );
}
