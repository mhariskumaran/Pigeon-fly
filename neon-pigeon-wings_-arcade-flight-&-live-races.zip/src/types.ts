export type GameMode = 'endless' | 'race';

export interface PigeonSkin {
  id: string;
  name: string;
  price: number; // in-game coins, 0 if starter or seasonal
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  description: string;
  primaryColor: string;
  secondaryColor: string;
  eyeColor: string;
  beakColor: string;
  glowColor: string;
  trailColor: string;
  particleType: 'feathers' | 'sparks' | 'matrix' | 'fire' | 'rainbow' | 'disco';
  isSeasonal?: boolean;
}

export interface UserProfile {
  id: string;
  username: string;
  isGuest: boolean;
  coins: number;
  highScore: number; // in meters
  totalDistance: number;
  totalCoinsEarned: number;
  racesWon: number;
  racesPlayed: number;
  equippedSkin: string;
  unlockedSkins: string[];
  claimedSeasonTiers: number[];
  seasonPoints: number;
  completedQuests: string[];
  createdAt: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  rewardCoins: number;
  rewardSeasonPoints: number;
  target: number;
  progress: number;
  completed: boolean;
  claimed: boolean;
  type: 'distance_single' | 'coins_single' | 'rings_single' | 'lasers_dodged' | 'races_won' | 'total_distance';
}

export interface SeasonTier {
  tier: number;
  pointsRequired: number;
  rewardType: 'coins' | 'skin' | 'badge';
  rewardValue: number | string;
  rewardTitle: string;
  skinData?: PigeonSkin;
}

export interface SeasonInfo {
  seasonNumber: number;
  title: string;
  endDate: number; // timestamp
  tiers: SeasonTier[];
}

export type ObstacleType = 
  | 'laser_gate' 
  | 'wind_zone' 
  | 'cyber_pillar' 
  | 'patrol_drone' 
  | 'bonus_ring';

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: ObstacleType;
  passed: boolean;
  // Dynamic properties:
  vy?: number;
  minY?: number;
  maxY?: number;
  active?: boolean;
  windForce?: number; // positive = pushes up, negative = pushes down
  radius?: number; // for bonus ring or plasma
}

export interface Coin {
  id: string;
  x: number;
  y: number;
  isRainbow: boolean;
  value: number;
  radius: number;
  collected: boolean;
}

export interface Powerup {
  id: string;
  x: number;
  y: number;
  type: 'shield' | 'magnet' | 'turbo';
  collected: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface Biome {
  name: string;
  minDistance: number;
  skyGradient: [string, string, string];
  cityColor: string;
  gridColor: string;
  fogColor: string;
  ambientLight: string;
}

export interface LeaderboardEntry {
  id: string;
  username: string;
  highScore: number;
  totalCoinsEarned: number;
  racesWon: number;
  skin: string;
  updatedAt: number;
}

// Multiplayer WebSocket Types
export interface RacePlayer {
  id: string;
  username: string;
  skinId: string;
  isReady: boolean;
  x: number;
  y: number;
  vy: number;
  distance: number;
  finished: boolean;
  finishTime?: number;
  crashed: boolean;
  rank?: number;
}

export interface RaceRoom {
  id: string;
  name: string;
  status: 'waiting' | 'starting' | 'racing' | 'finished';
  maxPlayers: number;
  targetDistance: number;
  seed: number;
  countdown: number;
  players: Record<string, RacePlayer>;
  winnerId?: string;
  createdAt: number;
}

export type WSClientMessage = 
  | { type: 'join_lobby'; username: string; skinId: string }
  | { type: 'create_room'; roomName: string; maxPlayers?: number }
  | { type: 'join_room'; roomId: string }
  | { type: 'toggle_ready' }
  | { type: 'pilot_update'; distance: number; y: number; vy: number; crashed: boolean }
  | { type: 'finish_race'; distance: number; finishTime: number }
  | { type: 'send_chat'; message: string };

export type WSServerMessage =
  | { type: 'welcome'; playerId: string; rooms: RaceRoom[] }
  | { type: 'room_list'; rooms: RaceRoom[] }
  | { type: 'room_state'; room: RaceRoom }
  | { type: 'countdown'; count: number }
  | { type: 'race_start'; seed: number; targetDistance: number }
  | { type: 'pilot_sync'; pilots: Record<string, Partial<RacePlayer>> }
  | { type: 'race_over'; winnerId: string; standings: RacePlayer[] }
  | { type: 'chat_broadcast'; sender: string; message: string; timestamp: number }
  | { type: 'error'; message: string };
