import { Biome, Coin, Obstacle, Particle, PigeonSkin, Powerup, RacePlayer } from '../types';

export function drawBiomeBackground(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  biome: Biome,
  scrollX: number
) {
  // Saturated Sky Gradient
  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, biome.skyGradient[0]);
  grad.addColorStop(0.5, biome.skyGradient[1]);
  grad.addColorStop(1, biome.skyGradient[2]);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Distant Neon Sun / Cyber Orb on horizon
  const sunY = height * 0.45;
  const sunRadius = 60;
  const sunGrad = ctx.createRadialGradient(width * 0.7, sunY, 10, width * 0.7, sunY, sunRadius);
  sunGrad.addColorStop(0, '#ffffff');
  sunGrad.addColorStop(0.3, biome.ambientLight);
  sunGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(width * 0.7, sunY, sunRadius * 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Horizontal scan lines on the sun for retro synthwave feel
  ctx.fillStyle = biome.skyGradient[1];
  for (let i = 0; i < 7; i++) {
    const lineY = sunY - 15 + i * 10;
    const lineHeight = 1 + i * 0.7;
    ctx.fillRect(width * 0.7 - sunRadius, lineY, sunRadius * 2, lineHeight);
  }

  // Parallax Layer 1: Distant Cyber Skyline
  ctx.fillStyle = biome.cityColor;
  const layer1Offset = (scrollX * 0.15) % 300;
  const buildingWidth = 50;
  for (let x = -layer1Offset - 100; x < width + 100; x += buildingWidth) {
    const hash = Math.sin(Math.floor((x + layer1Offset) / buildingWidth) * 999);
    const bHeight = 120 + Math.abs(hash) * 160;
    const bY = height - bHeight;
    ctx.fillRect(x, bY, buildingWidth - 6, bHeight);

    // Subtle windows
    ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    for (let wy = bY + 15; wy < height - 20; wy += 25) {
      ctx.fillRect(x + 10, wy, 8, 12);
      ctx.fillRect(x + 26, wy, 8, 12);
    }
    ctx.fillStyle = biome.cityColor;
  }

  // Parallax Layer 2: Cyber Grid Ground Floor
  const gridHeight = 100;
  const gridTop = height - gridHeight;
  const gridGrad = ctx.createLinearGradient(0, gridTop, 0, height);
  gridGrad.addColorStop(0, 'rgba(0,0,0,0.8)');
  gridGrad.addColorStop(1, '#000000');
  ctx.fillStyle = gridGrad;
  ctx.fillRect(0, gridTop, width, gridHeight);

  // Moving grid lines
  ctx.strokeStyle = biome.gridColor;
  ctx.lineWidth = 1.5;
  const gridSpacing = 40;
  const gridOffset = (scrollX * 0.8) % gridSpacing;

  // Perspective vertical lines converging
  ctx.beginPath();
  for (let x = -gridOffset; x < width + 60; x += gridSpacing) {
    ctx.moveTo(x, height);
    ctx.lineTo(x * 0.6 + width * 0.2, gridTop);
  }
  // Horizontal grid lines
  for (let y = gridTop; y <= height; y += 18) {
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
  }
  ctx.stroke();

  // Top ceiling warning boundary
  ctx.strokeStyle = 'rgba(244, 63, 94, 0.3)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 10);
  ctx.lineTo(width, 10);
  ctx.stroke();
}

export function drawPigeon(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  skin: PigeonSkin,
  vy: number,
  wingPhase: number,
  isInvincible: boolean = false,
  activeShield: boolean = false,
  activeTurbo: boolean = false,
  callsign?: string
) {
  ctx.save();
  ctx.translate(x, y);

  // Tilt with velocity: upward flight tilts nose up, falling tilts nose down
  const tilt = Math.max(-0.4, Math.min(0.6, vy * 0.05));
  ctx.rotate(tilt);

  // High-contrast glow
  ctx.shadowColor = skin.glowColor;
  ctx.shadowBlur = activeTurbo ? 25 : 12;

  // Thruster trail emission when boosting
  if (activeTurbo || vy < 0) {
    ctx.fillStyle = skin.trailColor;
    ctx.beginPath();
    ctx.moveTo(-18, 0);
    ctx.lineTo(-34 - (activeTurbo ? 18 : 6), -3);
    ctx.lineTo(-24, 0);
    ctx.lineTo(-34 - (activeTurbo ? 18 : 6), 3);
    ctx.closePath();
    ctx.fill();
  }

  // Tail feathers
  ctx.fillStyle = skin.secondaryColor;
  ctx.beginPath();
  ctx.moveTo(-12, -4);
  ctx.lineTo(-24, -12);
  ctx.lineTo(-20, 0);
  ctx.lineTo(-24, 8);
  ctx.lineTo(-12, 4);
  ctx.closePath();
  ctx.fill();

  // Body: Aerodynamic neon pigeon body
  ctx.fillStyle = skin.primaryColor;
  ctx.beginPath();
  ctx.ellipse(0, 0, 18, 11, 0, 0, Math.PI * 2);
  ctx.fill();

  // Pigeon Head
  ctx.beginPath();
  ctx.arc(14, -6, 9, 0, Math.PI * 2);
  ctx.fill();

  // Chest iridescent neon patch
  ctx.fillStyle = skin.secondaryColor;
  ctx.beginPath();
  ctx.arc(6, 2, 7, 0, Math.PI * 2);
  ctx.fill();

  // Wing: Flapping calculation based on wingPhase
  const wingAngle = Math.sin(wingPhase) * 0.7;
  ctx.save();
  ctx.translate(-2, -3);
  ctx.rotate(wingAngle);

  // Wing outer
  ctx.fillStyle = skin.secondaryColor;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-14, -18, -4, -20);
  ctx.quadraticCurveTo(8, -14, 10, 0);
  ctx.closePath();
  ctx.fill();

  // Wing feather highlight lines
  ctx.strokeStyle = skin.primaryColor;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(0, -2);
  ctx.lineTo(-4, -16);
  ctx.moveTo(4, -2);
  ctx.lineTo(2, -14);
  ctx.stroke();
  ctx.restore();

  // Pigeon Beak (sharp aerodynamic neon triangle)
  ctx.fillStyle = skin.beakColor;
  ctx.beginPath();
  ctx.moveTo(21, -8);
  ctx.lineTo(31, -5);
  ctx.lineTo(21, -2);
  ctx.closePath();
  ctx.fill();

  // Pigeon Eye / Cyber Visor
  if (skin.id === 'vaporwave_drip') {
    // Retro sunglasses
    ctx.fillStyle = '#000000';
    ctx.fillRect(13, -9, 8, 4);
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1;
    ctx.strokeRect(13, -9, 8, 4);
  } else {
    // Cyber Eye with glow
    ctx.fillStyle = skin.eyeColor;
    ctx.beginPath();
    ctx.arc(16, -7, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(17, -7, 1.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Active Shield Bubble
  if (activeShield) {
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(4, 0, 26, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
    ctx.fill();
  }

  // Invincibility flashing aura
  if (isInvincible && Math.floor(Date.now() / 80) % 2 === 0) {
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(4, 0, 24, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();

  // Callsign nameplate above pilot
  if (callsign) {
    ctx.save();
    ctx.font = 'bold 10px "Press Start 2P", monospace';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 4;
    ctx.fillText(callsign, x + 4, y - 30);
    ctx.restore();
  }
}

export function drawObstacles(
  ctx: CanvasRenderingContext2D,
  obstacles: Obstacle[],
  cameraX: number
) {
  obstacles.forEach((obs) => {
    const screenX = obs.x - cameraX;

    if (obs.type === 'laser_gate') {
      // Top emitter
      ctx.fillStyle = '#1e1b4b';
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      ctx.fillRect(screenX, obs.y, obs.width, 16);
      ctx.strokeRect(screenX, obs.y, obs.width, 16);

      // Bottom emitter
      ctx.fillRect(screenX, obs.y + obs.height - 16, obs.width, 16);
      ctx.strokeRect(screenX, obs.y + obs.height - 16, obs.width, 16);

      // Active Laser Beams
      const time = Date.now() * 0.008;
      const pulseAlpha = 0.7 + Math.sin(time) * 0.3;
      ctx.shadowColor = '#f43f5e';
      ctx.shadowBlur = 20;

      // Laser Core Beam (high contrast red/pink)
      ctx.fillStyle = `rgba(244, 63, 94, ${pulseAlpha})`;
      ctx.fillRect(screenX + obs.width * 0.3, obs.y + 16, obs.width * 0.4, obs.height - 32);

      // Laser White Center Strand
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(screenX + obs.width * 0.42, obs.y + 16, obs.width * 0.16, obs.height - 32);

      // Spark arcs
      ctx.strokeStyle = '#fecdd3';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const sparkY = obs.y + 20 + ((Date.now() * 0.2) % (obs.height - 40));
      ctx.moveTo(screenX + 2, sparkY);
      ctx.lineTo(screenX + obs.width - 2, sparkY + (Math.random() - 0.5) * 8);
      ctx.stroke();

      ctx.shadowBlur = 0;
    } 
    else if (obs.type === 'wind_zone') {
      // Shimmering aerodynamic wind tunnel with moving arrows
      const windPushUp = (obs.windForce || 1) > 0;
      ctx.save();
      const grad = ctx.createLinearGradient(screenX, obs.y, screenX, obs.y + obs.height);
      grad.addColorStop(0, 'rgba(6, 182, 212, 0.15)');
      grad.addColorStop(0.5, 'rgba(56, 189, 248, 0.35)');
      grad.addColorStop(1, 'rgba(6, 182, 212, 0.15)');
      ctx.fillStyle = grad;
      ctx.fillRect(screenX, obs.y, obs.width, obs.height);

      ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(screenX, obs.y, obs.width, obs.height);

      // Floating wind chevrons
      const arrowPhase = (Date.now() * 0.1) % 30;
      ctx.fillStyle = '#38bdf8';
      for (let py = obs.y + 20; py < obs.y + obs.height - 20; py += 35) {
        const drawY = windPushUp ? py - arrowPhase : py + arrowPhase;
        if (drawY > obs.y && drawY < obs.y + obs.height - 10) {
          ctx.beginPath();
          ctx.moveTo(screenX + obs.width * 0.5, drawY + (windPushUp ? -6 : 6));
          ctx.lineTo(screenX + obs.width * 0.2, drawY + (windPushUp ? 4 : -4));
          ctx.lineTo(screenX + obs.width * 0.8, drawY + (windPushUp ? 4 : -4));
          ctx.closePath();
          ctx.fill();
        }
      }

      // Wind zone label
      ctx.font = 'bold 9px "Press Start 2P", monospace';
      ctx.fillStyle = '#67e8f9';
      ctx.textAlign = 'center';
      ctx.fillText(windPushUp ? '▲ UP DRAFT ▲' : '▼ DOWN DRAFT ▼', screenX + obs.width * 0.5, obs.y + 14);
      ctx.restore();
    } 
    else if (obs.type === 'bonus_ring') {
      // Golden / Neon Cyan Bonus Ring
      const radius = obs.radius || 32;
      const centerY = obs.y + radius;
      const centerX = screenX + radius;

      ctx.save();
      ctx.shadowColor = '#facc15';
      ctx.shadowBlur = 18;

      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.stroke();

      // Inner pulsating neon ring
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius - 3, 0, Math.PI * 2);
      ctx.stroke();

      // Center score tag
      ctx.font = 'bold 8px "Press Start 2P", monospace';
      ctx.fillStyle = '#fef08a';
      ctx.textAlign = 'center';
      ctx.fillText('+RING', centerX, centerY + 3);
      ctx.restore();
    } 
    else if (obs.type === 'patrol_drone') {
      // Cyber Drone sentry
      ctx.save();
      const centerX = screenX + obs.width * 0.5;
      const centerY = obs.y + obs.height * 0.5;

      ctx.shadowColor = '#ef4444';
      ctx.shadowBlur = 15;

      // Drone chassis
      ctx.fillStyle = '#1e293b';
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Drone rotors
      const rotorAngle = Date.now() * 0.05;
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(centerX - 20 * Math.cos(rotorAngle), centerY - 8);
      ctx.lineTo(centerX + 20 * Math.cos(rotorAngle), centerY - 8);
      ctx.stroke();

      // Glowing red ocular sensor
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
      ctx.fill();

      // Scanning cone beam downward
      const coneGrad = ctx.createLinearGradient(centerX, centerY, centerX, centerY + 50);
      coneGrad.addColorStop(0, 'rgba(239, 68, 68, 0.4)');
      coneGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = coneGrad;
      ctx.beginPath();
      ctx.moveTo(centerX - 4, centerY);
      ctx.lineTo(centerX - 24, centerY + 50);
      ctx.lineTo(centerX + 24, centerY + 50);
      ctx.lineTo(centerX + 4, centerY);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    } 
    else {
      // Cyber Pillar / Spike
      ctx.save();
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = '#ec4899';
      ctx.lineWidth = 2;
      ctx.fillRect(screenX, obs.y, obs.width, obs.height);
      ctx.strokeRect(screenX, obs.y, obs.width, obs.height);

      // Warning hazard stripes
      ctx.fillStyle = 'rgba(236, 72, 153, 0.3)';
      for (let sy = obs.y; sy < obs.y + obs.height; sy += 24) {
        ctx.beginPath();
        ctx.moveTo(screenX, sy);
        ctx.lineTo(screenX + obs.width, sy + 12);
        ctx.lineTo(screenX + obs.width, sy + 20);
        ctx.lineTo(screenX, sy + 8);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
  });
}

export function drawCoins(
  ctx: CanvasRenderingContext2D,
  coins: Coin[],
  cameraX: number
) {
  coins.forEach((coin) => {
    if (coin.collected) return;
    const screenX = coin.x - cameraX;

    ctx.save();
    const spinWidth = Math.abs(Math.cos(Date.now() * 0.005 + coin.x * 0.1)) * coin.radius;

    if (coin.isRainbow) {
      // Rare Rainbow Coin
      const time = Date.now() * 0.003;
      const hue = Math.floor((time * 60 + coin.x) % 360);
      ctx.shadowColor = `hsl(${hue}, 100%, 60%)`;
      ctx.shadowBlur = 15;

      ctx.fillStyle = `hsl(${hue}, 100%, 55%)`;
      ctx.beginPath();
      ctx.ellipse(screenX, coin.y, Math.max(3, spinWidth), coin.radius, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Prismatic star sparkle
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(screenX, coin.y, 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Neon Gold Coin
      ctx.shadowColor = '#eab308';
      ctx.shadowBlur = 10;

      ctx.fillStyle = '#eab308';
      ctx.beginPath();
      ctx.ellipse(screenX, coin.y, Math.max(2, spinWidth), coin.radius, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Coin currency emblem
      if (spinWidth > 5) {
        ctx.font = 'bold 8px "Press Start 2P", monospace';
        ctx.fillStyle = '#78350f';
        ctx.textAlign = 'center';
        ctx.fillText('¢', screenX, coin.y + 3);
      }
    }
    ctx.restore();
  });
}

export function drawPowerups(
  ctx: CanvasRenderingContext2D,
  powerups: Powerup[],
  cameraX: number
) {
  powerups.forEach((pw) => {
    if (pw.collected) return;
    const screenX = pw.x - cameraX;
    const pulse = Math.sin(Date.now() * 0.006) * 2;

    ctx.save();
    if (pw.type === 'shield') {
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#0284c7';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(screenX, pw.y, 14 + pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🛡️', screenX, pw.y + 4);
    } else if (pw.type === 'magnet') {
      ctx.shadowColor = '#ec4899';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#db2777';
      ctx.strokeStyle = '#f472b6';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(screenX, pw.y, 14 + pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🧲', screenX, pw.y + 4);
    } else {
      ctx.shadowColor = '#eab308';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#ca8a04';
      ctx.strokeStyle = '#fde047';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(screenX, pw.y, 14 + pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('⚡', screenX, pw.y + 4);
    }
    ctx.restore();
  });
}

export function drawParticles(
  ctx: CanvasRenderingContext2D,
  particles: Particle[],
  cameraX: number
) {
  particles.forEach((p) => {
    const screenX = p.x - cameraX;
    ctx.save();
    ctx.globalAlpha = p.alpha;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.arc(screenX, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });
}

export function drawRemotePilots(
  ctx: CanvasRenderingContext2D,
  pilots: Record<string, RacePlayer>,
  currentPilotId: string,
  cameraX: number,
  skins: Record<string, PigeonSkin>
) {
  Object.values(pilots).forEach((pilot) => {
    if (pilot.id === currentPilotId) return; // Drawn separately
    if (pilot.crashed) return;

    // In a race, pilots x is related to distance:
    const screenX = pilot.distance - cameraX + 120; // 120 is local pigeon viewport anchor
    if (screenX < -100 || screenX > ctx.canvas.width + 100) return;

    const skin = skins[pilot.skinId] || skins['classic_cyber'];
    drawPigeon(
      ctx,
      screenX,
      pilot.y,
      skin,
      pilot.vy || 0,
      Date.now() * 0.015,
      false,
      false,
      false,
      pilot.username
    );
  });
}
