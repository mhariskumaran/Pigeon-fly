import { BIOMES } from './constants';
import { Biome, Coin, Obstacle, Powerup } from '../types';

// Deterministic or pseudo-random generator
export class LevelGenerator {
  private lastGeneratedX: number = 400;
  private seed: number;

  constructor(seed: number = 1337) {
    this.seed = seed;
  }

  private random(): number {
    const x = Math.sin(this.seed++) * 10000;
    return x - Math.floor(x);
  }

  public reset(seed: number = 1337) {
    this.seed = seed;
    this.lastGeneratedX = 400;
  }

  public getCurrentBiome(distance: number): Biome {
    for (let i = BIOMES.length - 1; i >= 0; i--) {
      if (distance >= BIOMES[i].minDistance) {
        return BIOMES[i];
      }
    }
    return BIOMES[0];
  }

  public generateChunk(
    targetX: number,
    canvasHeight: number
  ): {
    obstacles: Obstacle[];
    coins: Coin[];
    powerups: Powerup[];
  } {
    const obstacles: Obstacle[] = [];
    const coins: Coin[] = [];
    const powerups: Powerup[] = [];

    const minGap = 220; // distance between major hazards
    const playableTop = 40;
    const playableBottom = canvasHeight - 120;
    const playableRange = playableBottom - playableTop;

    while (this.lastGeneratedX < targetX) {
      this.lastGeneratedX += minGap + this.random() * 120;
      const x = this.lastGeneratedX;
      const roll = this.random();

      // 1. Obstacle variants
      if (roll < 0.32) {
        // Moving Laser Gate
        const gateHeight = 110 + this.random() * 80;
        const startY = playableTop + this.random() * (playableRange - gateHeight);
        obstacles.push({
          id: `laser_${x}`,
          x,
          y: startY,
          width: 36,
          height: gateHeight,
          type: 'laser_gate',
          passed: false,
          vy: (this.random() > 0.5 ? 1 : -1) * (1.2 + this.random() * 1.5),
          minY: playableTop,
          maxY: playableBottom - gateHeight,
        });

        // Chance to spawn coins above or below laser
        if (this.random() < 0.6) {
          const coinY = startY > playableTop + 80 ? startY - 45 : startY + gateHeight + 25;
          coins.push({
            id: `c_laser_${x}`,
            x: x + 18,
            y: coinY,
            isRainbow: this.random() < 0.15,
            value: 1,
            radius: 9,
            collected: false,
          });
        }
      } 
      else if (roll < 0.55) {
        // Wind Zone (Updraft or Downdraft)
        const windWidth = 140 + this.random() * 80;
        const windHeight = 140 + this.random() * 70;
        const isUpdraft = this.random() > 0.45;
        const wy = playableTop + this.random() * (playableRange - windHeight);
        obstacles.push({
          id: `wind_${x}`,
          x,
          y: wy,
          width: windWidth,
          height: windHeight,
          type: 'wind_zone',
          passed: false,
          windForce: isUpdraft ? 0.38 : -0.38,
        });

        // Place coins line inside wind zone rewarding careful navigation
        for (let ci = 0; ci < 3; ci++) {
          coins.push({
            id: `c_w_${x}_${ci}`,
            x: x + 30 + ci * 35,
            y: wy + windHeight * 0.5,
            isRainbow: this.random() < 0.2,
            value: 1,
            radius: 9,
            collected: false,
          });
        }
      } 
      else if (roll < 0.75) {
        // Bonus Ring (Reward Ring)
        const radius = 32;
        const ringY = playableTop + radius + this.random() * (playableRange - radius * 2);
        obstacles.push({
          id: `ring_${x}`,
          x,
          y: ringY,
          width: radius * 2,
          height: radius * 2,
          type: 'bonus_ring',
          passed: false,
          radius,
        });

        // Center bonus coin (often Rainbow!)
        coins.push({
          id: `c_ring_${x}`,
          x: x + radius,
          y: ringY + radius,
          isRainbow: this.random() < 0.4,
          value: 1,
          radius: 11,
          collected: false,
        });
      } 
      else if (roll < 0.88) {
        // Patrol Drone sentry
        const droneHeight = 32;
        const dy = playableTop + 30 + this.random() * (playableRange - 60);
        obstacles.push({
          id: `drone_${x}`,
          x,
          y: dy,
          width: 36,
          height: droneHeight,
          type: 'patrol_drone',
          passed: false,
          vy: (this.random() > 0.5 ? 1 : -1) * (1.5 + this.random() * 1.8),
          minY: playableTop + 10,
          maxY: playableBottom - 30,
        });
      } 
      else {
        // Cyber Pillar / Neon Spire
        const fromCeiling = this.random() > 0.5;
        const pillarHeight = 100 + this.random() * 120;
        const pillarWidth = 45;
        const py = fromCeiling ? playableTop - 20 : playableBottom - pillarHeight + 20;

        obstacles.push({
          id: `pillar_${x}`,
          x,
          y: py,
          width: pillarWidth,
          height: pillarHeight,
          type: 'cyber_pillar',
          passed: false,
        });

        // Arc of coins over or under pillar
        for (let i = 0; i < 4; i++) {
          const coinX = x - 20 + i * 25;
          const arcOffset = Math.sin((i / 3) * Math.PI) * 40;
          const coinY = fromCeiling ? py + pillarHeight + 40 + arcOffset : py - 40 - arcOffset;
          coins.push({
            id: `c_arc_${x}_${i}`,
            x: coinX,
            y: Math.max(playableTop + 10, Math.min(playableBottom - 10, coinY)),
            isRainbow: i === 2 && this.random() < 0.35,
            value: 1,
            radius: 9,
            collected: false,
          });
        }
      }

      // Occasional Powerup spawn (Shield, Magnet, Turbo)
      if (this.random() < 0.16) {
        const pTypes: Array<'shield' | 'magnet' | 'turbo'> = ['shield', 'magnet', 'turbo'];
        const type = pTypes[Math.floor(this.random() * pTypes.length)];
        powerups.push({
          id: `pw_${x}`,
          x: x + 90,
          y: playableTop + 40 + this.random() * (playableRange - 80),
          type,
          collected: false,
        });
      }
    }

    return { obstacles, coins, powerups };
  }
}
