import { RacePlayer, RaceRoom, WSClientMessage, WSServerMessage } from '../types';

export type WSCallback<T> = (data: T) => void;

class WebSocketClient {
  private ws: WebSocket | null = null;
  private isConnecting: boolean = false;
  private reconnectTimeout: number | null = null;
  public playerId: string = '';
  public currentRoom: RaceRoom | null = null;
  public roomsList: RaceRoom[] = [];
  public remotePilots: Record<string, RacePlayer> = {};

  // Event Listeners
  private onRoomListListeners: Array<WSCallback<RaceRoom[]>> = [];
  private onRoomStateListeners: Array<WSCallback<RaceRoom>> = [];
  private onCountdownListeners: Array<WSCallback<number>> = [];
  private onRaceStartListeners: Array<WSCallback<{ seed: number; targetDistance: number }>> = [];
  private onRaceOverListeners: Array<WSCallback<{ winnerId: string; standings: RacePlayer[] }>> = [];
  private onChatListeners: Array<WSCallback<{ sender: string; message: string; timestamp: number }>> = [];
  private onErrorListeners: Array<WSCallback<string>> = [];

  public connect(username: string, skinId: string) {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.isConnecting = true;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        this.send({
          type: 'join_lobby',
          username,
          skinId,
        });
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data) as WSServerMessage;
          this.handleServerMessage(msg);
        } catch (e) {
          console.error('Failed to parse WS msg', e);
        }
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.ws = null;
        // Auto reconnect after 3 seconds if not unmounted
        if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
        this.reconnectTimeout = window.setTimeout(() => {
          this.connect(username, skinId);
        }, 3000);
      };

      this.ws.onerror = (err) => {
        console.warn('WS error:', err);
      };
    } catch (e) {
      this.isConnecting = false;
      console.warn('WS connection failed:', e);
    }
  }

  public disconnect() {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  public send(msg: WSClientMessage) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  private handleServerMessage(msg: WSServerMessage) {
    switch (msg.type) {
      case 'welcome':
        this.playerId = msg.playerId;
        this.roomsList = msg.rooms;
        this.onRoomListListeners.forEach((cb) => cb(msg.rooms));
        break;

      case 'room_list':
        this.roomsList = msg.rooms;
        this.onRoomListListeners.forEach((cb) => cb(msg.rooms));
        break;

      case 'room_state':
        this.currentRoom = msg.room;
        this.remotePilots = { ...msg.room.players };
        this.onRoomStateListeners.forEach((cb) => cb(msg.room));
        break;

      case 'countdown':
        this.onCountdownListeners.forEach((cb) => cb(msg.count));
        break;

      case 'race_start':
        this.onRaceStartListeners.forEach((cb) => cb(msg));
        break;

      case 'pilot_sync':
        Object.entries(msg.pilots).forEach(([id, delta]) => {
          if (this.remotePilots[id]) {
            Object.assign(this.remotePilots[id], delta);
          }
        });
        break;

      case 'race_over':
        this.onRaceOverListeners.forEach((cb) => cb(msg));
        break;

      case 'chat_broadcast':
        this.onChatListeners.forEach((cb) => cb(msg));
        break;

      case 'error':
        this.onErrorListeners.forEach((cb) => cb(msg.message));
        break;
    }
  }

  public onRoomList(cb: WSCallback<RaceRoom[]>) {
    this.onRoomListListeners.push(cb);
    return () => {
      this.onRoomListListeners = this.onRoomListListeners.filter((c) => c !== cb);
    };
  }

  public onRoomState(cb: WSCallback<RaceRoom>) {
    this.onRoomStateListeners.push(cb);
    return () => {
      this.onRoomStateListeners = this.onRoomStateListeners.filter((c) => c !== cb);
    };
  }

  public onCountdown(cb: WSCallback<number>) {
    this.onCountdownListeners.push(cb);
    return () => {
      this.onCountdownListeners = this.onCountdownListeners.filter((c) => c !== cb);
    };
  }

  public onRaceStart(cb: WSCallback<{ seed: number; targetDistance: number }>) {
    this.onRaceStartListeners.push(cb);
    return () => {
      this.onRaceStartListeners = this.onRaceStartListeners.filter((c) => c !== cb);
    };
  }

  public onRaceOver(cb: WSCallback<{ winnerId: string; standings: RacePlayer[] }>) {
    this.onRaceOverListeners.push(cb);
    return () => {
      this.onRaceOverListeners = this.onRaceOverListeners.filter((c) => c !== cb);
    };
  }

  public onChat(cb: WSCallback<{ sender: string; message: string; timestamp: number }>) {
    this.onChatListeners.push(cb);
    return () => {
      this.onChatListeners = this.onChatListeners.filter((c) => c !== cb);
    };
  }

  public onError(cb: WSCallback<string>) {
    this.onErrorListeners.push(cb);
    return () => {
      this.onErrorListeners = this.onErrorListeners.filter((c) => c !== cb);
    };
  }
}

export const wsClient = new WebSocketClient();
