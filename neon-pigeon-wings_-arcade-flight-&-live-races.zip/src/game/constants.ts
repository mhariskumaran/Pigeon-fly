import { Biome, PigeonSkin, Quest, SeasonInfo, UserProfile } from '../types';

export const PIGEON_SKINS: PigeonSkin[] = [
  {
    id: 'classic_cyber',
    name: 'Cyber Classic',
    price: 0,
    rarity: 'common',
    description: 'Standard issue high-altitude neon cyber pigeon with cyan photon wings.',
    primaryColor: '#06b6d4', // cyan-500
    secondaryColor: '#f43f5e', // rose-500
    eyeColor: '#ffffff',
    beakColor: '#fbbf24',
    glowColor: 'rgba(6, 182, 212, 0.6)',
    trailColor: '#06b6d4',
    particleType: 'sparks',
  },
  {
    id: 'solar_phoenix',
    name: 'Solar Phoenix',
    price: 350,
    rarity: 'rare',
    description: 'Forged in radioactive plasma flare zones. Leaves an incandescent flame exhaust.',
    primaryColor: '#f97316', // orange-500
    secondaryColor: '#e11d48', // rose-600
    eyeColor: '#fef08a',
    beakColor: '#fde047',
    glowColor: 'rgba(249, 115, 22, 0.7)',
    trailColor: '#ff5500',
    particleType: 'fire',
  },
  {
    id: 'matrix_glider',
    name: 'Matrix Glider',
    price: 600,
    rarity: 'rare',
    description: 'Coded with executable binary algorithms. Wingtips stream cascading cyber runes.',
    primaryColor: '#22c55e', // green-500
    secondaryColor: '#14532d', // green-900
    eyeColor: '#86efac',
    beakColor: '#4ade80',
    glowColor: 'rgba(34, 197, 94, 0.7)',
    trailColor: '#22c55e',
    particleType: 'matrix',
  },
  {
    id: 'vaporwave_drip',
    name: 'Vaporwave Drip',
    price: 900,
    rarity: 'epic',
    description: '1986 Japanese aesthetic nostalgia pigeon equipped with shaded aviators.',
    primaryColor: '#e879f9', // fuchsia-400
    secondaryColor: '#38bdf8', // sky-400
    eyeColor: '#000000',
    beakColor: '#fbbf24',
    glowColor: 'rgba(232, 121, 249, 0.7)',
    trailColor: '#e879f9',
    particleType: 'disco',
  },
  {
    id: 'golden_mecha',
    name: 'Golden Mecha',
    price: 1500,
    rarity: 'legendary',
    description: 'Titanium-gilded stealth aerofoil plating. Emits pure luxury golden sparks.',
    primaryColor: '#eab308', // yellow-500
    secondaryColor: '#ca8a04', // yellow-600
    eyeColor: '#ffffff',
    beakColor: '#fef08a',
    glowColor: 'rgba(234, 179, 8, 0.8)',
    trailColor: '#facc15',
    particleType: 'sparks',
  },
  {
    id: 'phantom_stealth',
    name: 'Phantom Stealth',
    price: 1800,
    rarity: 'epic',
    description: 'Radar-absorbent midnight violet composite. Slides silently through wind zones.',
    primaryColor: '#8b5cf6', // violet-500
    secondaryColor: '#1e1b4b', // indigo-950
    eyeColor: '#a78bfa',
    beakColor: '#c084fc',
    glowColor: 'rgba(139, 92, 246, 0.7)',
    trailColor: '#8b5cf6',
    particleType: 'feathers',
  },
  {
    id: 'rainbow_prism',
    name: 'Rainbow Prism',
    price: 2500,
    rarity: 'legendary',
    description: 'Holographic diffraction feathering that bends the spectrum of neon starlight.',
    primaryColor: '#ec4899', // pink-500
    secondaryColor: '#06b6d4', // cyan-500
    eyeColor: '#ffffff',
    beakColor: '#fbbf24',
    glowColor: 'rgba(236, 72, 153, 0.8)',
    trailColor: '#f43f5e',
    particleType: 'rainbow',
  },
  {
    id: 'neon_disco',
    name: 'Neon Disco Ace',
    price: 0,
    rarity: 'legendary',
    description: 'Seasonal Grand Champion skin. Strobing RGB plumage and confetti thrust.',
    primaryColor: '#a855f7',
    secondaryColor: '#06b6d4',
    eyeColor: '#f43f5e',
    beakColor: '#fbbf24',
    glowColor: 'rgba(168, 85, 247, 0.8)',
    trailColor: '#06b6d4',
    particleType: 'disco',
    isSeasonal: true,
  }
];

export const BIOMES: Biome[] = [
  {
    name: 'Synthwave Sunset',
    minDistance: 0,
    skyGradient: ['#0f051d', '#3b0764', '#831843'],
    cityColor: '#581c87',
    gridColor: 'rgba(236, 72, 153, 0.4)',
    fogColor: 'rgba(244, 63, 94, 0.15)',
    ambientLight: '#ec4899',
  },
  {
    name: 'Cyber Matrix',
    minDistance: 600,
    skyGradient: ['#021811', '#064e3b', '#065f46'],
    cityColor: '#042f2e',
    gridColor: 'rgba(34, 197, 94, 0.4)',
    fogColor: 'rgba(16, 185, 129, 0.15)',
    ambientLight: '#10b981',
  },
  {
    name: 'Electric Neon Blue',
    minDistance: 1400,
    skyGradient: ['#05081c', '#1e1b4b', '#1e3a8a'],
    cityColor: '#172554',
    gridColor: 'rgba(6, 182, 212, 0.45)',
    fogColor: 'rgba(59, 130, 246, 0.15)',
    ambientLight: '#06b6d4',
  },
  {
    name: 'Solar Flare',
    minDistance: 2200,
    skyGradient: ['#1c0a00', '#7c2d12', '#991b1b'],
    cityColor: '#451a03',
    gridColor: 'rgba(249, 115, 22, 0.45)',
    fogColor: 'rgba(234, 88, 12, 0.15)',
    ambientLight: '#f97316',
  },
  {
    name: 'Hyper Void Aurora',
    minDistance: 3200,
    skyGradient: ['#030712', '#111827', '#1f2937'],
    cityColor: '#374151',
    gridColor: 'rgba(217, 70, 239, 0.5)',
    fogColor: 'rgba(168, 85, 247, 0.2)',
    ambientLight: '#d946ef',
  },
];

export const INITIAL_QUESTS: Quest[] = [
  {
    id: 'q_coins_single',
    title: 'Neon Hoarder',
    description: 'Collect 25 neon coins in a single flight session',
    rewardCoins: 80,
    rewardSeasonPoints: 120,
    target: 25,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'coins_single',
  },
  {
    id: 'q_rings_single',
    title: 'Acrobatic Glide',
    description: 'Fly through 4 bonus rings in a single run',
    rewardCoins: 100,
    rewardSeasonPoints: 150,
    target: 4,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'rings_single',
  },
  {
    id: 'q_distance_voyager',
    title: 'Horizon Breaker',
    description: 'Reach a flight distance of 800m in one endless journey',
    rewardCoins: 120,
    rewardSeasonPoints: 200,
    target: 800,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'distance_single',
  },
  {
    id: 'q_lasers_dodged',
    title: 'Laser Ghost',
    description: 'Safely bypass 5 moving laser gates',
    rewardCoins: 90,
    rewardSeasonPoints: 140,
    target: 5,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'lasers_dodged',
  },
  {
    id: 'q_races_won',
    title: 'Skyways Dominator',
    description: 'Finish 1st place in a live multiplayer race room',
    rewardCoins: 250,
    rewardSeasonPoints: 350,
    target: 1,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'races_won',
  },
  {
    id: 'q_total_distance',
    title: 'Endless Aviator',
    description: 'Accumulate 3,000 meters total flight across all sorties',
    rewardCoins: 180,
    rewardSeasonPoints: 250,
    target: 3000,
    progress: 0,
    completed: false,
    claimed: false,
    type: 'total_distance',
  },
];

export const CURRENT_SEASON: SeasonInfo = {
  seasonNumber: 1,
  title: 'Neon Skyways: Grand Cyber Prix',
  endDate: Date.now() + 6 * 24 * 60 * 60 * 1000, // 6 days remaining
  tiers: [
    { tier: 1, pointsRequired: 100, rewardType: 'coins', rewardValue: 150, rewardTitle: '150 Neon Coins' },
    { tier: 2, pointsRequired: 250, rewardType: 'badge', rewardValue: 'Wingtips Cadet', rewardTitle: 'Cadet Pilot Badge' },
    { tier: 3, pointsRequired: 450, rewardType: 'coins', rewardValue: 300, rewardTitle: '300 Neon Coins' },
    { tier: 4, pointsRequired: 700, rewardType: 'badge', rewardValue: 'Photon Glider', rewardTitle: 'Photon Ace Badge' },
    { tier: 5, pointsRequired: 1000, rewardType: 'skin', rewardValue: 'solar_phoenix', rewardTitle: 'Solar Phoenix Skin Unlock', skinData: PIGEON_SKINS[1] },
    { tier: 6, pointsRequired: 1400, rewardType: 'coins', rewardValue: 500, rewardTitle: '500 Neon Coins' },
    { tier: 7, pointsRequired: 1900, rewardType: 'badge', rewardValue: 'Cyber Overlord', rewardTitle: 'Skyway Legend Badge' },
    { tier: 8, pointsRequired: 2500, rewardType: 'coins', rewardValue: 800, rewardTitle: '800 Neon Coins' },
    { tier: 9, pointsRequired: 3200, rewardType: 'badge', rewardValue: 'Pigeon Grandmaster', rewardTitle: 'Golden Crown Badge' },
    { tier: 10, pointsRequired: 4000, rewardType: 'skin', rewardValue: 'neon_disco', rewardTitle: 'Exclusive Neon Disco Ace Skin', skinData: PIGEON_SKINS[7] },
  ],
};

export function createDefaultProfile(): UserProfile {
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return {
    id: `guest_${Date.now()}_${randomSuffix}`,
    username: `Pilot_${randomSuffix}`,
    isGuest: true,
    coins: 150, // starter bank to try buying or upgrading
    highScore: 0,
    totalDistance: 0,
    totalCoinsEarned: 150,
    racesWon: 0,
    racesPlayed: 0,
    equippedSkin: 'classic_cyber',
    unlockedSkins: ['classic_cyber'],
    claimedSeasonTiers: [],
    seasonPoints: 120,
    completedQuests: [],
    createdAt: Date.now(),
  };
}
