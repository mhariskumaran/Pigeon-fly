import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Coins, Flag, Sparkles, RefreshCw } from 'lucide-react';
import { LeaderboardEntry, UserProfile } from '../types';
import { PIGEON_SKINS } from '../game/constants';

interface LeaderboardViewProps {
  profile: UserProfile;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ profile }) => {
  const [filter, setFilter] = useState<'distance' | 'coins' | 'wins'>('distance');
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchLeaderboard = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/leaderboard');
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data.leaderboard || []);
      }
    } catch (e) {
      console.warn('Failed to fetch leaderboard:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const skinMap = PIGEON_SKINS.reduce<Record<string, string>>((acc, s) => {
    acc[s.id] = s.name;
    return acc;
  }, {});

  // Sort based on current filter
  const sorted = [...leaderboard].sort((a, b) => {
    if (filter === 'distance') return b.highScore - a.highScore;
    if (filter === 'coins') return b.totalCoinsEarned - a.totalCoinsEarned;
    return b.racesWon - a.racesWon;
  });

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-6">
      
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <h2 className="text-base sm:text-xl font-pixel text-white">GLOBAL PILOT HALL OF FAME</h2>
          </div>
          <p className="text-xs text-zinc-400 font-display">
            The greatest cyber pigeons across the infinite neon skies.
          </p>
        </div>

        <button
          onClick={fetchLeaderboard}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-display transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Sync Scores</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 p-1 rounded-xl bg-zinc-900/90 border border-zinc-800 self-start">
        <button
          onClick={() => setFilter('distance')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
            filter === 'distance'
              ? 'bg-cyan-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
          <span>Endless Distance</span>
        </button>

        <button
          onClick={() => setFilter('coins')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
            filter === 'coins'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Coins className="w-3.5 h-3.5 text-amber-300" />
          <span>Coins Hoarded</span>
        </button>

        <button
          onClick={() => setFilter('wins')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
            filter === 'wins'
              ? 'bg-fuchsia-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Flag className="w-3.5 h-3.5 text-pink-300" />
          <span>Race Victories</span>
        </button>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-zinc-900/80 rounded-2xl border border-zinc-800 overflow-hidden shadow-xl">
        <div className="grid grid-cols-12 px-4 py-3 bg-zinc-950/60 border-b border-zinc-800 text-[10px] font-pixel text-zinc-400">
          <div className="col-span-2 sm:col-span-1 text-center">RANK</div>
          <div className="col-span-6 sm:col-span-5">PILOT CALLSIGN</div>
          <div className="hidden sm:block sm:col-span-3">EQUIPPED SKIN</div>
          <div className="col-span-4 sm:col-span-3 text-right">
            {filter === 'distance' ? 'RECORD' : filter === 'coins' ? 'COINS' : 'WINS'}
          </div>
        </div>

        <div className="divide-y divide-zinc-800/60">
          {sorted.map((pilot, idx) => {
            const isMe = pilot.username.toLowerCase() === profile.username.toLowerCase();
            const rank = idx + 1;

            return (
              <div
                key={pilot.id}
                className={`grid grid-cols-12 items-center px-4 py-3.5 transition-colors ${
                  isMe ? 'bg-cyan-950/30 text-cyan-200' : 'hover:bg-zinc-800/40 text-zinc-300'
                }`}
              >
                {/* Rank Medal */}
                <div className="col-span-2 sm:col-span-1 text-center font-pixel text-xs">
                  {rank === 1 ? (
                    <span className="text-yellow-400">🥇</span>
                  ) : rank === 2 ? (
                    <span className="text-slate-300">🥈</span>
                  ) : rank === 3 ? (
                    <span className="text-amber-600">🥉</span>
                  ) : (
                    <span className="text-zinc-500">#{rank}</span>
                  )}
                </div>

                {/* Pilot Name */}
                <div className="col-span-6 sm:col-span-5 flex items-center gap-2">
                  <span className="font-display font-bold text-sm text-white">{pilot.username}</span>
                  {isMe && (
                    <span className="px-1.5 py-0.2 rounded bg-cyan-900 text-cyan-300 font-pixel text-[9px]">
                      YOU
                    </span>
                  )}
                </div>

                {/* Skin */}
                <div className="hidden sm:flex sm:col-span-3 items-center gap-1.5 text-xs text-zinc-400 font-display">
                  <span>🕊️</span>
                  <span>{skinMap[pilot.skin] || 'Cyber Classic'}</span>
                </div>

                {/* Stat Metric */}
                <div className="col-span-4 sm:col-span-3 text-right font-pixel text-xs sm:text-sm">
                  {filter === 'distance' && (
                    <span className="text-cyan-400">{pilot.highScore.toLocaleString()}m</span>
                  )}
                  {filter === 'coins' && (
                    <span className="text-amber-400">🪙 {pilot.totalCoinsEarned.toLocaleString()}</span>
                  )}
                  {filter === 'wins' && (
                    <span className="text-pink-400">🏁 {pilot.racesWon} W</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
