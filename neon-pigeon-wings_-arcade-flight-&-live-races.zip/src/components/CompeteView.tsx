import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  Flag, Users, Trophy, Play, CheckCircle2, AlertCircle, 
  Send, Sparkles, Clock, Award, Shield, ArrowRight, RefreshCw 
} from 'lucide-react';
import { PigeonSkin, RacePlayer, RaceRoom, SeasonInfo, UserProfile } from '../types';
import { CURRENT_SEASON, PIGEON_SKINS } from '../game/constants';
import { wsClient } from '../game/websocketClient';
import { sounds } from '../audio/chiptune';
import { LevelGenerator } from '../game/generator';
import { 
  drawBiomeBackground, 
  drawPigeon, 
  drawObstacles, 
  drawCoins, 
  drawRemotePilots 
} from '../game/renderer';

interface CompeteViewProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
}

export const CompeteView: React.FC<CompeteViewProps> = ({ profile, onUpdateProfile }) => {
  const [subTab, setSubTab] = useState<'rooms' | 'season'>('rooms');
  const [rooms, setRooms] = useState<RaceRoom[]>([]);
  const [currentRoom, setCurrentRoom] = useState<RaceRoom | null>(null);
  const [newRoomName, setNewRoomName] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: string; message: string; timestamp: number }>>([]);
  const [inputChat, setInputChat] = useState<string>('');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isRacing, setIsRacing] = useState<boolean>(false);
  const [raceOverData, setRaceOverData] = useState<{ winnerId: string; standings: RacePlayer[] } | null>(null);

  // In-race player state
  const raceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const raceGameRef = useRef({
    distance: 0,
    y: 250,
    vy: 0,
    wingPhase: 0,
    crashed: false,
    finished: false,
    cameraX: 0,
    targetDistance: 1500,
    seed: 1337,
    generator: new LevelGenerator(1337),
    obstacles: [] as any[],
    coins: [] as any[],
    animationId: 0,
  });

  const equippedSkin = PIGEON_SKINS.find((s) => s.id === profile.equippedSkin) || PIGEON_SKINS[0];
  const skinMap = useRef<Record<string, PigeonSkin>>(
    PIGEON_SKINS.reduce((acc, s) => ({ ...acc, [s.id]: s }), {})
  ).current;

  // Initialize WebSocket connection
  useEffect(() => {
    wsClient.connect(profile.username, profile.equippedSkin);

    const unsubList = wsClient.onRoomList((newRooms) => {
      setRooms(newRooms);
    });

    const unsubState = wsClient.onRoomState((room) => {
      setCurrentRoom({ ...room });
      if (room.status === 'racing') {
        setIsRacing(true);
      } else if (room.status === 'finished') {
        setIsRacing(false);
      }
    });

    const unsubCount = wsClient.onCountdown((count) => {
      setCountdown(count);
      sounds.playCountdown();
    });

    const unsubStart = wsClient.onRaceStart(({ seed, targetDistance }) => {
      sounds.playStartRace();
      setCountdown(null);
      setIsRacing(true);
      setRaceOverData(null);

      // Reset race game ref
      const rg = raceGameRef.current;
      rg.distance = 0;
      rg.y = 250;
      rg.vy = 0;
      rg.crashed = false;
      rg.finished = false;
      rg.cameraX = 0;
      rg.targetDistance = targetDistance;
      rg.seed = seed;
      rg.generator.reset(seed);

      const chunk = rg.generator.generateChunk(3000, 480);
      rg.obstacles = chunk.obstacles;
      rg.coins = chunk.coins;
    });

    const unsubOver = wsClient.onRaceOver((data) => {
      setRaceOverData(data);
      setIsRacing(false);

      // Check if current user is winner!
      const userRank = data.standings.find((p) => p.id === wsClient.playerId)?.rank || 0;
      if (userRank === 1) {
        sounds.playPowerup();
        confetti({ particleCount: 120, spread: 80, colors: ['#f43f5e', '#06b6d4', '#eab308'] });
        onUpdateProfile({
          racesWon: profile.racesWon + 1,
          racesPlayed: profile.racesPlayed + 1,
          coins: profile.coins + 200,
          seasonPoints: profile.seasonPoints + 300,
        });
      } else {
        onUpdateProfile({
          racesPlayed: profile.racesPlayed + 1,
          coins: profile.coins + (userRank === 2 ? 100 : 50),
          seasonPoints: profile.seasonPoints + (userRank === 2 ? 150 : 80),
        });
      }
    });

    const unsubChat = wsClient.onChat((msg) => {
      setChatMessages((prev) => [...prev.slice(-20), msg]);
    });

    return () => {
      unsubList();
      unsubState();
      unsubCount();
      unsubStart();
      unsubOver();
      unsubChat();
    };
  }, [profile.username, profile.equippedSkin, profile.racesWon, profile.racesPlayed, profile.coins, profile.seasonPoints, onUpdateProfile]);

  // Race Canvas Loop
  useEffect(() => {
    if (!isRacing) return;
    const canvas = raceCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();
    let syncThrottle = 0;

    const loop = (time: number) => {
      const dt = Math.min(32, time - lastTime) / 16.666;
      lastTime = time;

      const rg = raceGameRef.current;
      const width = canvas.width;
      const height = canvas.height;

      if (!rg.crashed && !rg.finished) {
        // Continuous race speed forward
        rg.cameraX += 5.5 * dt;
        rg.distance = rg.cameraX * 0.15;

        // Gravity
        rg.vy += 0.28 * dt;
        rg.y += rg.vy * dt;
        rg.wingPhase += 0.14 * dt;

        // Boundaries
        if (rg.y >= height - 60) {
          rg.y = height - 60;
          rg.crashed = true;
          sounds.playCrash();
        }
        if (rg.y <= 24) {
          rg.y = 24;
          rg.vy = 0.5;
        }

        // Check Finish Line
        if (rg.distance >= rg.targetDistance) {
          rg.finished = true;
          sounds.playRainbowCoin();
          wsClient.send({
            type: 'finish_race',
            distance: rg.distance,
            finishTime: Date.now(),
          });
        }

        // Throttle WebSocket pilot update ~25 times/sec
        syncThrottle += dt;
        if (syncThrottle >= 2) {
          syncThrottle = 0;
          wsClient.send({
            type: 'pilot_update',
            distance: rg.distance,
            y: rg.y,
            vy: rg.vy,
            crashed: rg.crashed,
          });
        }
      }

      // Render
      ctx.clearRect(0, 0, width, height);
      const biome = rg.generator.getCurrentBiome(rg.distance);
      drawBiomeBackground(ctx, width, height, biome, rg.cameraX);
      drawObstacles(ctx, rg.obstacles, rg.cameraX);
      drawCoins(ctx, rg.coins, rg.cameraX);

      // Draw Remote Opponents
      drawRemotePilots(ctx, wsClient.remotePilots, wsClient.playerId, rg.cameraX, skinMap);

      // Draw Local Pigeon
      drawPigeon(
        ctx,
        120,
        rg.y,
        equippedSkin,
        rg.vy,
        rg.wingPhase,
        false,
        false,
        false,
        profile.username
      );

      rg.animationId = requestAnimationFrame(loop);
    };

    raceGameRef.current.animationId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raceGameRef.current.animationId);
  }, [isRacing, equippedSkin, profile.username, skinMap]);

  // Race flight flap input
  const handleRaceFlap = () => {
    if (!isRacing || raceGameRef.current.crashed || raceGameRef.current.finished) return;
    sounds.playFlap();
    raceGameRef.current.vy = -6.8;
    raceGameRef.current.wingPhase += 1.8;
  };

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newRoomName.trim() || `Neon Cup #${Math.floor(100 + Math.random() * 900)}`;
    wsClient.send({ type: 'create_room', roomName: name, maxPlayers: 4 });
    setNewRoomName('');
  };

  const handleJoinRoom = (roomId: string) => {
    sounds.playCoin();
    wsClient.send({ type: 'join_room', roomId });
  };

  const handleToggleReady = () => {
    sounds.playCoin();
    wsClient.send({ type: 'toggle_ready' });
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputChat.trim()) return;
    wsClient.send({ type: 'send_chat', message: inputChat });
    setInputChat('');
  };

  const handleClaimSeasonTier = (tier: number) => {
    const tierData = CURRENT_SEASON.tiers.find((t) => t.tier === tier);
    if (!tierData) return;
    sounds.playPowerup();
    confetti({ particleCount: 60, spread: 60 });

    const newClaimed = [...profile.claimedSeasonTiers, tier];
    let extraCoins = 0;
    const newUnlocked = [...profile.unlockedSkins];

    if (tierData.rewardType === 'coins') {
      extraCoins = Number(tierData.rewardValue);
    } else if (tierData.rewardType === 'skin' && typeof tierData.rewardValue === 'string') {
      if (!newUnlocked.includes(tierData.rewardValue)) {
        newUnlocked.push(tierData.rewardValue);
      }
    }

    onUpdateProfile({
      claimedSeasonTiers: newClaimed,
      coins: profile.coins + extraCoins,
      unlockedSkins: newUnlocked,
    });
  };

  const currentRoomPlayers: RacePlayer[] = currentRoom ? (Object.values(currentRoom.players) as RacePlayer[]) : [];
  const localPlayer = currentRoom ? currentRoom.players[wsClient.playerId] : null;

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-6">
      
      {/* Sub-Tabs: Live Race Rooms vs Season Skyways */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-3">
          <button
            id="compete-rooms-tab"
            onClick={() => setSubTab('rooms')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-display font-bold text-xs sm:text-sm transition-all ${
              subTab === 'rooms'
                ? 'bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white shadow-lg shadow-fuchsia-500/20'
                : 'text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800'
            }`}
          >
            <Users className="w-4 h-4 text-pink-300" />
            <span>Live WebSocket Race Rooms</span>
            <span className="px-1.5 py-0.5 rounded text-[9px] bg-black/40 text-pink-200 font-pixel">
              {rooms.length} Active
            </span>
          </button>

          <button
            id="compete-season-tab"
            onClick={() => setSubTab('season')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-display font-bold text-xs sm:text-sm transition-all ${
              subTab === 'season'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-600 text-white shadow-lg shadow-yellow-500/20'
                : 'text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-300" />
            <span>Season 1 Skyways</span>
            <span className="px-1.5 py-0.5 rounded text-[9px] bg-black/40 text-amber-200 font-pixel">
              {profile.seasonPoints} PTS
            </span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs font-display text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Server-Authoritative Room Sync</span>
        </div>
      </div>

      {/* SUB-TAB 1: LIVE RACE ROOMS */}
      {subTab === 'rooms' && (
        <div className="flex flex-col gap-6">
          
          {/* If actively racing */}
          {isRacing ? (
            <div className="relative w-full rounded-2xl overflow-hidden border-2 border-fuchsia-500 bg-black shadow-2xl shadow-fuchsia-950/60 select-none">
              {/* Race HUD */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-none">
                <div className="bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-fuchsia-500/50 text-fuchsia-300 font-pixel text-xs">
                  🏁 LIVE RACE: {Math.floor(raceGameRef.current.distance)}m / {raceGameRef.current.targetDistance}m
                </div>

                {/* Progress Bar of all pilots */}
                <div className="bg-zinc-950/80 px-4 py-1.5 rounded-xl border border-zinc-700 flex items-center gap-3 w-64 max-w-xs">
                  <div className="relative w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className="absolute top-0 bottom-0 bg-cyan-400 transition-all"
                      style={{ width: `${Math.min(100, (raceGameRef.current.distance / raceGameRef.current.targetDistance) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-pixel text-zinc-300">
                    {Math.min(100, Math.floor((raceGameRef.current.distance / raceGameRef.current.targetDistance) * 100))}%
                  </span>
                </div>
              </div>

              {/* Race Canvas */}
              <canvas
                ref={raceCanvasRef}
                width={800}
                height={460}
                onClick={handleRaceFlap}
                className="w-full h-[400px] sm:h-[460px] block cursor-pointer touch-none"
              />

              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs font-pixel text-white/70 bg-black/60 px-3 py-1 rounded-lg pointer-events-none">
                TAP / CLICK / SPACE TO FLAP
              </div>
            </div>
          ) : raceOverData ? (
            /* Race Over Standings Podium */
            <div className="bg-zinc-900/90 rounded-2xl border border-fuchsia-500/50 p-6 shadow-2xl text-center">
              <div className="text-4xl mb-2">🏆</div>
              <h2 className="text-xl sm:text-2xl font-pixel text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-400 to-cyan-400 mb-2">
                RACE COMPLETED!
              </h2>
              <p className="text-xs font-display text-zinc-400 mb-6">
                Winner: <strong className="text-amber-300 font-pixel">{raceOverData.standings[0]?.username || 'Ace'}</strong>
              </p>

              {/* Standings List */}
              <div className="max-w-md mx-auto flex flex-col gap-2 mb-6">
                {raceOverData.standings.map((player, idx) => (
                  <div
                    key={player.id}
                    className={`flex items-center justify-between p-3 rounded-xl border ${
                      idx === 0
                        ? 'bg-amber-950/40 border-amber-500/60 text-amber-200'
                        : 'bg-zinc-950/60 border-zinc-800 text-zinc-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-pixel text-xs font-bold w-6">#{idx + 1}</span>
                      <span className="font-display font-semibold text-sm">{player.username}</span>
                      {player.id === wsClient.playerId && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-pixel">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-pixel text-right">
                      <div className="text-amber-300">
                        {idx === 0 ? '+200 🪙 +300 PTS' : idx === 1 ? '+100 🪙 +150 PTS' : '+50 🪙 +80 PTS'}
                      </div>
                      <div className="text-[10px] text-zinc-400">
                        {player.finished ? 'Finished' : `${Math.floor(player.distance)}m`}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-center gap-3">
                <button
                  id="race-again-btn"
                  onClick={() => {
                    setRaceOverData(null);
                    handleToggleReady();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 text-zinc-950 font-pixel text-xs font-bold shadow-lg shadow-cyan-500/30 hover:scale-105 transition-all cursor-pointer"
                >
                  READY FOR NEXT RACE
                </button>
              </div>
            </div>
          ) : currentRoom ? (
            /* Inside Room Lobby */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Room Status & Pilots */}
              <div className="lg:col-span-2 bg-zinc-900/80 rounded-2xl border border-zinc-800 p-5 flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3 mb-4">
                    <div>
                      <h3 className="font-pixel text-sm text-pink-300">{currentRoom.name}</h3>
                      <p className="text-xs text-zinc-400 font-display">Target Distance: 1,500m Dash</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-1 rounded bg-zinc-800 text-zinc-300 text-[10px] font-pixel">
                        {currentRoomPlayers.length}/{currentRoom.maxPlayers} PILOTS
                      </span>
                    </div>
                  </div>

                  {/* Connected Pilots Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                    {currentRoomPlayers.map((player) => {
                      const pSkin = skinMap[player.skinId] || skinMap['classic_cyber'];
                      return (
                        <div
                          key={player.id}
                          className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/70 border border-zinc-800"
                        >
                          <div className="flex items-center gap-2.5">
                            <div 
                              className="w-8 h-8 rounded-lg flex items-center justify-center text-base"
                              style={{ backgroundColor: pSkin.primaryColor + '33', border: `1px solid ${pSkin.primaryColor}` }}
                            >
                              🕊️
                            </div>
                            <div>
                              <div className="font-display font-semibold text-xs text-white flex items-center gap-1.5">
                                <span>{player.username}</span>
                                {player.id === wsClient.playerId && (
                                  <span className="text-[9px] text-cyan-400 font-pixel">(You)</span>
                                )}
                              </div>
                              <div className="text-[10px] text-zinc-400 font-display">
                                {pSkin.name}
                              </div>
                            </div>
                          </div>

                          <div>
                            {player.isReady ? (
                              <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-500/50 text-emerald-400 text-[9px] font-pixel">
                                <CheckCircle2 className="w-3 h-3" />
                                READY
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[9px] font-pixel">
                                WAITING
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Ready & Countdown Controls */}
                <div className="pt-4 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-3">
                  {countdown !== null ? (
                    <div className="flex items-center gap-3 text-amber-300 font-pixel text-sm animate-bounce">
                      <Clock className="w-5 h-5 animate-spin" />
                      <span>RACE STARTING IN {countdown}...</span>
                    </div>
                  ) : (
                    <div className="text-xs text-zinc-400 font-display">
                      {localPlayer?.isReady ? 'Waiting for pilots to lock in ready status...' : 'Toggle Ready to begin!'}
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      id="room-ready-btn"
                      onClick={handleToggleReady}
                      className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-pixel text-xs font-bold transition-all cursor-pointer ${
                        localPlayer?.isReady
                          ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-500 text-zinc-950 shadow-lg shadow-emerald-500/30 hover:scale-105'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{localPlayer?.isReady ? 'CANCEL READY' : 'SET READY [GO]'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* In-Room Chat & Taunts */}
              <div className="bg-zinc-900/80 rounded-2xl border border-zinc-800 p-4 flex flex-col justify-between h-[360px]">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-2">
                  <span className="font-pixel text-xs text-zinc-300">FLIGHT COMMS</span>
                  <span className="text-[10px] text-zinc-500 font-display">Encrypted</span>
                </div>

                {/* Messages feed */}
                <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs">
                  {chatMessages.length === 0 ? (
                    <div className="text-zinc-600 text-center py-8 font-display">
                      Send a wing-tap or coo to connected pilots!
                    </div>
                  ) : (
                    chatMessages.map((m, i) => (
                      <div key={i} className="bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/80">
                        <span className="font-pixel text-[10px] text-cyan-400 mr-2">{m.sender}:</span>
                        <span className="text-zinc-200 font-display">{m.message}</span>
                      </div>
                    ))
                  )}
                </div>

                {/* Quick Taunt Buttons */}
                <div className="flex flex-wrap gap-1.5 my-2">
                  {['Coo! 🕊️', 'Fast wings!', 'Watch the lasers!', 'Eat my neon trail!'].map((taunt) => (
                    <button
                      key={taunt}
                      onClick={() => wsClient.send({ type: 'send_chat', message: taunt })}
                      className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-display transition-colors"
                    >
                      {taunt}
                    </button>
                  ))}
                </div>

                {/* Chat input */}
                <form onSubmit={handleSendChat} className="flex gap-2">
                  <input
                    type="text"
                    value={inputChat}
                    onChange={(e) => setInputChat(e.target.value)}
                    placeholder="Type callsign comms..."
                    maxLength={70}
                    className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-display"
                  />
                  <button
                    type="submit"
                    className="p-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>
            </div>
          ) : (
            /* Rooms Lobby: List and Create */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Active Rooms List */}
              <div className="lg:col-span-2 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-pixel text-xs sm:text-sm text-cyan-400">AVAILABLE RACE ROOMS</h3>
                  <button
                    onClick={() => wsClient.send({ type: 'join_lobby', username: profile.username, skinId: profile.equippedSkin })}
                    className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-cyan-300 font-display"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {rooms.length === 0 ? (
                    <div className="col-span-2 text-center py-12 bg-zinc-900/40 rounded-2xl border border-dashed border-zinc-800">
                      <p className="text-zinc-500 font-display mb-3">No active race rooms found.</p>
                      <button
                        onClick={() => wsClient.send({ type: 'create_room', roomName: 'Neon Grand Prix', maxPlayers: 4 })}
                        className="px-4 py-2 rounded-xl bg-cyan-600 text-white font-pixel text-xs hover:bg-cyan-500"
                      >
                        CREATE FIRST ROOM
                      </button>
                    </div>
                  ) : (
                    rooms.map((r) => {
                      const count = Object.keys(r.players).length;
                      const isFull = count >= r.maxPlayers;
                      return (
                        <div
                          key={r.id}
                          className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-cyan-500/50 transition-all flex flex-col justify-between shadow-lg"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-pixel text-xs text-fuchsia-300 truncate max-w-[170px]">{r.name}</span>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-pixel ${
                                r.status === 'racing' ? 'bg-amber-950 text-amber-400' : 'bg-zinc-800 text-zinc-300'
                              }`}>
                                {r.status.toUpperCase()}
                              </span>
                            </div>
                            <p className="text-[11px] text-zinc-400 font-display mb-4">
                              Length: {r.targetDistance}m • {count}/{r.maxPlayers} Connected Pilots
                            </p>
                          </div>

                          <button
                            id={`join-room-${r.id}`}
                            onClick={() => handleJoinRoom(r.id)}
                            disabled={isFull || r.status === 'racing'}
                            className={`w-full py-2 rounded-xl font-pixel text-xs transition-all flex items-center justify-center gap-1.5 ${
                              isFull || r.status === 'racing'
                                ? 'bg-zinc-800/60 text-zinc-600 cursor-not-allowed'
                                : 'bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white shadow-md shadow-cyan-600/20 cursor-pointer'
                            }`}
                          >
                            <span>{isFull ? 'ROOM FULL' : r.status === 'racing' ? 'IN PROGRESS' : 'JOIN FLIGHT DECK'}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Create Custom Room Panel */}
              <div className="bg-zinc-900/80 rounded-2xl border border-zinc-800 p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <h3 className="font-pixel text-xs sm:text-sm text-pink-400 mb-2">HOST RACE ROOM</h3>
                  <p className="text-xs text-zinc-400 font-display mb-4">
                    Create a synchronized room to race friends and online pilots on an identical course seed.
                  </p>

                  <form onSubmit={handleCreateRoom} className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-pixel text-zinc-400 mb-1">ROOM CALLSIGN / NAME</label>
                      <input
                        type="text"
                        value={newRoomName}
                        onChange={(e) => setNewRoomName(e.target.value)}
                        placeholder="e.g. Neon Dash Alpha"
                        maxLength={24}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-fuchsia-500 font-display"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 text-[11px] font-display text-zinc-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Course Length:</span>
                        <span className="text-cyan-300 font-pixel">1,500m Dash</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Max Competitors:</span>
                        <span className="text-white font-pixel">4 Pilots</span>
                      </div>
                      <div className="flex justify-between">
                        <span>1st Place Bounty:</span>
                        <span className="text-amber-300 font-pixel">+200 Coins</span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-fuchsia-600 via-pink-600 to-rose-600 hover:from-fuchsia-500 hover:to-pink-500 text-white font-pixel text-xs font-bold shadow-lg shadow-fuchsia-500/25 transition-all cursor-pointer"
                    >
                      LAUNCH NEW ROOM
                    </button>
                  </form>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-800 text-[10px] text-zinc-500 font-display">
                  Tip: Open another browser tab to test live multiplayer flight synchronization in real-time!
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: SEASON 1 SKYWAYS REWARDS */}
      {subTab === 'season' && (
        <div className="flex flex-col gap-6">
          {/* Season Header Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/80 via-zinc-950 to-amber-950/80 border-2 border-amber-500/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded bg-amber-500 text-zinc-950 font-pixel text-[10px] font-bold">
                  SEASON 1
                </span>
                <span className="text-xs font-display text-amber-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Weekly Reset in 6 Days
                </span>
              </div>
              <h2 className="text-lg sm:text-2xl font-pixel text-white mb-1">
                {CURRENT_SEASON.title}
              </h2>
              <p className="text-xs text-zinc-400 font-display">
                Earn Season Points by flying endless distances and winning live race matches to unlock exclusive skins.
              </p>
            </div>

            <div className="bg-zinc-900/90 border border-amber-500/30 p-4 rounded-xl text-right">
              <div className="text-[10px] font-pixel text-amber-400 mb-1">YOUR SEASON SCORE</div>
              <div className="text-2xl font-pixel text-white">{profile.seasonPoints} <span className="text-xs text-amber-400">PTS</span></div>
            </div>
          </div>

          {/* Tier Milestones Roadmap */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {CURRENT_SEASON.tiers.map((t) => {
              const isUnlocked = profile.seasonPoints >= t.pointsRequired;
              const isClaimed = profile.claimedSeasonTiers.includes(t.tier);

              return (
                <div
                  key={t.tier}
                  className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
                    isClaimed
                      ? 'bg-zinc-900/60 border-zinc-800 opacity-75'
                      : isUnlocked
                      ? 'bg-gradient-to-b from-amber-950/40 to-zinc-900 border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'bg-zinc-900/40 border-zinc-800/80'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-pixel text-[10px] text-amber-400">TIER {t.tier}</span>
                      <span className="text-[10px] font-pixel text-zinc-400">{t.pointsRequired} pts</span>
                    </div>

                    <div className="my-3 text-center">
                      <div className="text-2xl mb-1">
                        {t.rewardType === 'coins' ? '🪙' : t.rewardType === 'skin' ? '🕊️' : '🎖️'}
                      </div>
                      <div className="font-display font-semibold text-xs text-white">{t.rewardTitle}</div>
                    </div>
                  </div>

                  <div>
                    {isClaimed ? (
                      <div className="w-full py-1.5 rounded-lg bg-zinc-800 text-zinc-400 font-pixel text-[10px] text-center">
                        CLAIMED
                      </div>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => handleClaimSeasonTier(t.tier)}
                        className="w-full py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 text-zinc-950 font-pixel text-[10px] font-bold shadow-md hover:scale-102 transition-all cursor-pointer"
                      >
                        CLAIM REWARD
                      </button>
                    ) : (
                      <div className="w-full py-1.5 rounded-lg bg-zinc-900 text-zinc-600 font-pixel text-[10px] text-center border border-zinc-800">
                        LOCKED
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
