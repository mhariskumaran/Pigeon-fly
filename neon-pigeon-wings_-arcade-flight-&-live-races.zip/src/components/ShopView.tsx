import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Feather, Check, Lock, Sparkles, Coins, Eye } from 'lucide-react';
import { PigeonSkin, UserProfile } from '../types';
import { PIGEON_SKINS } from '../game/constants';
import { sounds } from '../audio/chiptune';
import { drawPigeon } from '../game/renderer';

interface ShopViewProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onStartFlight: () => void;
}

export const ShopView: React.FC<ShopViewProps> = ({ profile, onUpdateProfile, onStartFlight }) => {
  const [selectedSkin, setSelectedSkin] = useState<PigeonSkin>(
    PIGEON_SKINS.find((s) => s.id === profile.equippedSkin) || PIGEON_SKINS[0]
  );
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Animated live preview on canvas
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let wingPhase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Cyber backdrop circle
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const rad = 70;

      const grad = ctx.createRadialGradient(cx, cy, 10, cx, cy, rad);
      grad.addColorStop(0, selectedSkin.glowColor);
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, rad, 0, Math.PI * 2);
      ctx.fill();

      // Draw Animated Pigeon
      wingPhase += 0.08;
      drawPigeon(ctx, cx, cy, selectedSkin, -0.5, wingPhase, false, false, false);

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [selectedSkin]);

  const isUnlocked = profile.unlockedSkins.includes(selectedSkin.id);
  const isEquipped = profile.equippedSkin === selectedSkin.id;
  const canAfford = profile.coins >= selectedSkin.price;

  const handleBuySkin = (skin: PigeonSkin) => {
    if (profile.coins < skin.price) return;

    sounds.playPowerup();
    confetti({
      particleCount: 100,
      spread: 70,
      colors: [skin.primaryColor, skin.secondaryColor, '#fde047'],
    });

    onUpdateProfile({
      coins: profile.coins - skin.price,
      unlockedSkins: [...profile.unlockedSkins, skin.id],
      equippedSkin: skin.id,
    });
  };

  const handleEquipSkin = (skin: PigeonSkin) => {
    sounds.playCoin();
    onUpdateProfile({
      equippedSkin: skin.id,
    });
  };

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case 'legendary':
        return 'bg-amber-950/80 text-amber-300 border-amber-500/60';
      case 'epic':
        return 'bg-fuchsia-950/80 text-fuchsia-300 border-fuchsia-500/60';
      case 'rare':
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-500/60';
      default:
        return 'bg-zinc-800 text-zinc-300 border-zinc-700';
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-6">
      
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Feather className="w-5 h-5 text-amber-400" />
            <h2 className="text-base sm:text-xl font-pixel text-white">COSMETIC PIGEON HANGAR</h2>
          </div>
          <p className="text-xs text-zinc-400 font-display">
            Unlock aerodynamic wings and neon trails using your real in-game flight coin earnings.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-950/40 border border-amber-500/50 text-amber-300 font-pixel text-sm shadow-md">
            <span>🪙</span>
            <span>{profile.coins.toLocaleString()} Coins</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Skin Cards & Live Hologram Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Skins Grid */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {PIGEON_SKINS.map((skin) => {
            const unlocked = profile.unlockedSkins.includes(skin.id);
            const equipped = profile.equippedSkin === skin.id;
            const isSelected = selectedSkin.id === skin.id;

            return (
              <div
                key={skin.id}
                onClick={() => {
                  sounds.playCoin();
                  setSelectedSkin(skin);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-cyan-400 bg-zinc-900/90 shadow-lg shadow-cyan-950/50 scale-101'
                    : 'border-zinc-800 bg-zinc-950/60 hover:border-zinc-700 hover:bg-zinc-900/50'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-pixel border ${getRarityBadge(skin.rarity)}`}>
                      {skin.rarity.toUpperCase()}
                    </span>

                    {equipped ? (
                      <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 font-pixel text-[9px] flex items-center gap-1">
                        <Check className="w-3 h-3" /> EQUIPPED
                      </span>
                    ) : unlocked ? (
                      <span className="text-[10px] text-zinc-400 font-display">UNLOCKED</span>
                    ) : skin.isSeasonal ? (
                      <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 text-[9px] font-pixel">
                        SEASON REWARD
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] font-pixel text-amber-400">
                        <span>🪙</span>
                        <span>{skin.price}</span>
                      </span>
                    )}
                  </div>

                  {/* Skin Card Title & Color Indicators */}
                  <div className="flex items-center gap-3 mb-2">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-inner"
                      style={{
                        backgroundColor: skin.primaryColor + '22',
                        border: `2px solid ${skin.primaryColor}`,
                      }}
                    >
                      🕊️
                    </div>
                    <div>
                      <h4 className="font-pixel text-xs text-white">{skin.name}</h4>
                      <p className="text-[10px] text-zinc-400 font-display line-clamp-1">{skin.description}</p>
                    </div>
                  </div>
                </div>

                {/* Card Action */}
                <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs font-display">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-zinc-500">Trail:</span>
                    <span 
                      className="w-2.5 h-2.5 rounded-full inline-block"
                      style={{ backgroundColor: skin.trailColor }}
                    />
                    <span className="text-[10px] text-zinc-400 capitalize">{skin.particleType}</span>
                  </div>

                  <span className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold">
                    Inspect
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Col: Selected Skin Hologram Stage */}
        <div className="bg-zinc-900/90 rounded-2xl border border-zinc-800 p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className={`px-2.5 py-0.5 rounded text-[10px] font-pixel border ${getRarityBadge(selectedSkin.rarity)}`}>
                {selectedSkin.rarity.toUpperCase()}
              </span>
              <span className="text-xs text-zinc-400 font-display">Live Preview</span>
            </div>

            {/* Holographic Canvas Stage */}
            <div className="relative w-full h-48 rounded-xl bg-black/80 border border-zinc-800 flex items-center justify-center overflow-hidden mb-5">
              <div className="absolute inset-0 crt-scanlines opacity-50"></div>
              <canvas ref={previewCanvasRef} width={260} height={180} className="relative z-10" />
            </div>

            <h3 className="font-pixel text-sm text-white mb-1">{selectedSkin.name}</h3>
            <p className="text-xs text-zinc-400 font-display mb-4">{selectedSkin.description}</p>

            {/* Specs */}
            <div className="space-y-2 p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80 text-xs font-display text-zinc-300 mb-6">
              <div className="flex justify-between">
                <span className="text-zinc-500">Plumage Primary:</span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedSkin.primaryColor }} />
                  <span className="font-mono text-[11px]">{selectedSkin.primaryColor}</span>
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Aerofoil Accent:</span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedSkin.secondaryColor }} />
                  <span className="font-mono text-[11px]">{selectedSkin.secondaryColor}</span>
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Exhaust Particles:</span>
                <span className="text-cyan-300 capitalize font-semibold">{selectedSkin.particleType}</span>
              </div>
            </div>
          </div>

          {/* Buy or Equip Button */}
          <div>
            {isEquipped ? (
              <button
                disabled
                className="w-full py-3 rounded-xl bg-zinc-800 text-emerald-400 font-pixel text-xs flex items-center justify-center gap-2 cursor-default border border-emerald-500/30"
              >
                <Check className="w-4 h-4" />
                <span>CURRENTLY EQUIPPED</span>
              </button>
            ) : isUnlocked ? (
              <button
                onClick={() => handleEquipSkin(selectedSkin)}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white font-pixel text-xs font-bold shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
              >
                EQUIP THIS SKIN
              </button>
            ) : selectedSkin.isSeasonal ? (
              <div className="text-center p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-300 font-pixel text-[10px]">
                UNLOCK VIA COMPETE SEASON TIERS
              </div>
            ) : canAfford ? (
              <button
                onClick={() => handleBuySkin(selectedSkin)}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 font-pixel text-xs font-bold shadow-lg shadow-yellow-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>BUY FOR {selectedSkin.price} 🪙</span>
              </button>
            ) : (
              <div className="text-center p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500 font-pixel text-[10px]">
                NEED {selectedSkin.price - profile.coins} MORE COINS TO UNLOCK
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
