import React, { useRef, useEffect, useState, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Play, RotateCcw, Shield, Zap, Magnet, Trophy, Coins, Compass, Sparkles, Volume2, Flag } from 'lucide-react';
import { Coin, Obstacle, Particle, PigeonSkin, Powerup, UserProfile } from '../types';
import { LevelGenerator } from '../game/generator';
import { PIGEON_SKINS } from '../game/constants';
import { sounds } from '../audio/chiptune';
import {
  drawBiomeBackground,
  drawPigeon,
  drawObstacles,
  drawCoins,
  drawPowerups,
  drawParticles,
} from '../game/renderer';

interface FlightGameViewProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onGoToShop: () => void;
  onGoToCompete: () => void;
}

export const FlightGameView: React.FC<FlightGameViewProps> = ({
  profile,
  onUpdateProfile,
  onGoToShop,
  onGoToCompete,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Game State
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'gameover'>('idle');
  const [distance, setDistance] = useState<number>(0);
  const [coinsCollectedThisRun, setCoinsCollectedThisRun] = useState<number>(0);
  const [ringsPassedThisRun, setRingsPassedThisRun] = useState<number>(0);
  const [multiplier, setMultiplier] = useState<number>(1);
  const [biomeName, setBiomeName] = useState<string>('Synthwave Sunset');
  const [biomeBanner, setBiomeBanner] = useState<string | null>(null);

  // Active powerups timers
  const [shieldActive, setShieldActive] = useState<boolean>(false);
  const [magnetTimer, setMagnetTimer] = useState<number>(0);
  const [turboTimer, setTurboTimer] = useState<number>(0);

  // High score flag
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);

  // Mutable Game Loop State in ref to guarantee 60fps without React state lagging
  const gameRef = useRef({
    x: 0,
    y: 250,
    vy: 0,
    cameraX: 0,
    scrollSpeed: 4.8,
    wingPhase: 0,
    invincibleTimer: 0,
    shield: false,
    magnetTime: 0,
    turboTime: 0,
    distance: 0,
    coinsCollected: 0,
    ringsPassed: 0,
    lasersDodged: 0,
    multiplier: 1,
    multiplierTimer: 0,
    obstacles: [] as Obstacle[],
    coins: [] as Coin[],
    powerups: [] as Powerup[],
    particles: [] as Particle[],
    lastBiomeIndex: 0,
    generator: new LevelGenerator(Date.now()),
    animationId: 0,
    isPlaying: false,
    canvasWidth: 800,
    canvasHeight: 500,
  });

  const equippedSkin: PigeonSkin =
    PIGEON_SKINS.find((s) => s.id === profile.equippedSkin) || PIGEON_SKINS[0];

  // Flap wings handler
  const triggerFlap = useCallback(() => {
    if (!gameRef.current.isPlaying) return;
    sounds.playFlap();
    // Upward velocity impulse with boost
    gameRef.current.vy = -6.8;
    gameRef.current.wingPhase += 1.8;

    // Spawn wing thruster particles
    const g = gameRef.current;
    for (let i = 0; i < 4; i++) {
      g.particles.push({
        x: g.cameraX + 100 - 15,
        y: g.y + (Math.random() - 0.5) * 10,
        vx: -3 - Math.random() * 3,
        vy: (Math.random() - 0.5) * 2,
        color: equippedSkin.trailColor,
        size: 2.5 + Math.random() * 2,
        alpha: 0.9,
        life: 0,
        maxLife: 20,
      });
    }
  }, [equippedSkin]);

  // Start new flight session
  const startGame = useCallback(() => {
    sounds.startMusic();
    sounds.playPowerup();

    const g = gameRef.current;
    g.x = 0;
    g.y = g.canvasHeight * 0.45;
    g.vy = -2;
    g.cameraX = 0;
    g.scrollSpeed = 4.8;
    g.wingPhase = 0;
    g.invincibleTimer = 0;
    g.shield = false;
    g.magnetTime = 0;
    g.turboTime = 0;
    g.distance = 0;
    g.coinsCollected = 0;
    g.ringsPassed = 0;
    g.lasersDodged = 0;
    g.multiplier = 1;
    g.multiplierTimer = 0;
    g.obstacles = [];
    g.coins = [];
    g.powerups = [];
    g.particles = [];
    g.lastBiomeIndex = 0;
    g.generator.reset(Date.now());
    g.isPlaying = true;

    // Pre-generate initial chunk
    const chunk = g.generator.generateChunk(g.canvasWidth + 1200, g.canvasHeight);
    g.obstacles = chunk.obstacles;
    g.coins = chunk.coins;
    g.powerups = chunk.powerups;

    setDistance(0);
    setCoinsCollectedThisRun(0);
    setRingsPassedThisRun(0);
    setMultiplier(1);
    setShieldActive(false);
    setMagnetTimer(0);
    setTurboTimer(0);
    setIsNewHighScore(false);
    setBiomeName('Synthwave Sunset');
    setBiomeBanner(null);
    setGameState('playing');
  }, []);

  // End flight session & process rewards
  const gameOver = useCallback(() => {
    sounds.playCrash();
    const g = gameRef.current;
    g.isPlaying = false;

    const runDistance = Math.floor(g.distance);
    const runCoins = g.coinsCollected;
    const isHigh = runDistance > profile.highScore;

    if (isHigh) {
      setIsNewHighScore(true);
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#f43f5e', '#eab308', '#22c55e', '#a855f7'],
      });
    }

    // Update player profile stats
    onUpdateProfile({
      coins: profile.coins + runCoins,
      highScore: Math.max(profile.highScore, runDistance),
      totalDistance: profile.totalDistance + runDistance,
      totalCoinsEarned: profile.totalCoinsEarned + runCoins,
      seasonPoints: profile.seasonPoints + Math.floor(runDistance / 10) + runCoins * 2,
    });

    setGameState('gameover');
  }, [profile, onUpdateProfile]);

  // Handle keyboard inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        if (gameState === 'playing') {
          triggerFlap();
        } else if (gameState === 'idle' || gameState === 'gameover') {
          startGame();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, triggerFlap, startGame]);

  // Main Canvas Render & Physics Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = Math.min(32, time - lastTime) / 16.666;
      lastTime = time;

      const g = gameRef.current;
      const width = canvas.width;
      const height = canvas.height;
      g.canvasWidth = width;
      g.canvasHeight = height;

      if (g.isPlaying) {
        // 1. Update Distance & Camera Speed
        const speedBoost = g.turboTime > 0 ? 2.0 : 1.0;
        const currentSpeed = (g.scrollSpeed + Math.min(4, g.distance * 0.001)) * speedBoost;
        g.cameraX += currentSpeed * dt;
        g.distance = g.cameraX * 0.15; // 1 distance unit per ~6.6 px

        // 2. Aerodynamic Physics: Gravity and Wind Forces
        const gravity = 0.28;
        g.vy += gravity * dt;

        // Apply wind zones affecting pigeon
        const pigeonX = g.cameraX + 120;
        g.obstacles.forEach((obs) => {
          if (obs.type === 'wind_zone' && obs.windForce) {
            if (
              pigeonX >= obs.x &&
              pigeonX <= obs.x + obs.width &&
              g.y >= obs.y &&
              g.y <= obs.y + obs.height
            ) {
              g.vy -= obs.windForce * 0.6 * dt; // wind push
            }
          }
        });

        // Update Pigeon Y
        g.y += g.vy * dt;
        g.wingPhase += 0.12 * dt;

        // Ceilings and Floor boundaries
        const floorY = height - 70;
        const ceilingY = 24;

        if (g.y >= floorY) {
          g.y = floorY;
          if (g.shield) {
            g.shield = false;
            setShieldActive(false);
            g.vy = -5;
          } else if (g.turboTime > 0) {
            g.vy = -4;
          } else {
            gameOver();
            return;
          }
        }
        if (g.y <= ceilingY) {
          g.y = ceilingY;
          g.vy = 0.5;
        }

        // 3. Update Moving Obstacles (Laser gates & drones oscillating)
        g.obstacles.forEach((obs) => {
          if (obs.vy && obs.minY !== undefined && obs.maxY !== undefined) {
            obs.y += obs.vy * dt;
            if (obs.y <= obs.minY || obs.y >= obs.maxY) {
              obs.vy = -obs.vy;
            }
          }
        });

        // 4. Update Powerup Timers
        if (g.invincibleTimer > 0) g.invincibleTimer -= dt * 16.666;
        if (g.magnetTime > 0) {
          g.magnetTime -= dt * 16.666;
          setMagnetTimer(Math.max(0, Math.ceil(g.magnetTime / 1000)));
        }
        if (g.turboTime > 0) {
          g.turboTime -= dt * 16.666;
          setTurboTimer(Math.max(0, Math.ceil(g.turboTime / 1000)));
        }

        // Multiplier decay
        if (g.multiplierTimer > 0) {
          g.multiplierTimer -= dt * 16.666;
          if (g.multiplierTimer <= 0) {
            g.multiplier = 1;
            setMultiplier(1);
          }
        }

        // 5. Check Biome Progression
        const currentBiome = g.generator.getCurrentBiome(g.distance);
        if (currentBiome.name !== biomeName) {
          setBiomeName(currentBiome.name);
          setBiomeBanner(`NOW ENTERING: ${currentBiome.name.toUpperCase()}`);
          setTimeout(() => setBiomeBanner(null), 3000);
        }

        // 6. Generate More Chunks as Player moves forward
        if (g.cameraX + width + 800 > g.generator['lastGeneratedX']) {
          const newChunk = g.generator.generateChunk(g.cameraX + width + 1400, height);
          g.obstacles.push(...newChunk.obstacles);
          g.coins.push(...newChunk.coins);
          g.powerups.push(...newChunk.powerups);
        }

        // 7. Cleanup Old Entities far behind camera
        g.obstacles = g.obstacles.filter((o) => o.x > g.cameraX - 200);
        g.coins = g.coins.filter((c) => c.x > g.cameraX - 100 && !c.collected);
        g.powerups = g.powerups.filter((p) => p.x > g.cameraX - 100 && !p.collected);

        // 8. Collisions: Coins & Magnetism
        const pR = 15; // collision radius
        g.coins.forEach((coin) => {
          if (coin.collected) return;

          // Magnet Attraction
          if (g.magnetTime > 0) {
            const dx = pigeonX - coin.x;
            const dy = g.y - coin.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 240) {
              coin.x += (dx / dist) * 9 * dt;
              coin.y += (dy / dist) * 9 * dt;
            }
          }

          const dx = pigeonX - coin.x;
          const dy = g.y - coin.y;
          if (Math.sqrt(dx * dx + dy * dy) < pR + coin.radius) {
            coin.collected = true;
            const coinGain = coin.isRainbow ? 10 : 1;
            g.coinsCollected += coinGain * g.multiplier;
            setCoinsCollectedThisRun(g.coinsCollected);

            if (coin.isRainbow) {
              sounds.playRainbowCoin();
              // Burst rainbow sparks
              for (let i = 0; i < 16; i++) {
                g.particles.push({
                  x: coin.x,
                  y: coin.y,
                  vx: (Math.random() - 0.5) * 8,
                  vy: (Math.random() - 0.5) * 8,
                  color: `hsl(${Math.random() * 360}, 100%, 65%)`,
                  size: 3 + Math.random() * 3,
                  alpha: 1,
                  life: 0,
                  maxLife: 28,
                });
              }
            } else {
              sounds.playCoin();
            }

            // Refresh multiplier timer
            g.multiplierTimer = 4000;
          }
        });

        // 9. Collisions: Powerups
        g.powerups.forEach((pw) => {
          if (pw.collected) return;
          const dx = pigeonX - pw.x;
          const dy = g.y - pw.y;
          if (Math.sqrt(dx * dx + dy * dy) < pR + 14) {
            pw.collected = true;
            sounds.playPowerup();

            if (pw.type === 'shield') {
              g.shield = true;
              setShieldActive(true);
            } else if (pw.type === 'magnet') {
              g.magnetTime = 8000;
              setMagnetTimer(8);
            } else if (pw.type === 'turbo') {
              g.turboTime = 5000;
              setTurboTimer(5);
            }
          }
        });

        // 10. Collisions: Obstacles
        for (const obs of g.obstacles) {
          // Bonus Rings: Check if passed center
          if (obs.type === 'bonus_ring') {
            const ringCenterX = obs.x + (obs.radius || 32);
            const ringCenterY = obs.y + (obs.radius || 32);
            const rDist = Math.sqrt(Math.pow(pigeonX - ringCenterX, 2) + Math.pow(g.y - ringCenterY, 2));

            if (rDist < (obs.radius || 32) && !obs.passed) {
              obs.passed = true;
              sounds.playRingPass();
              g.ringsPassed += 1;
              setRingsPassedThisRun(g.ringsPassed);

              // Boost multiplier & score
              g.multiplier = Math.min(4, g.multiplier + 1);
              g.multiplierTimer = 6000;
              setMultiplier(g.multiplier);

              // Speed impulse
              g.vy = -3;

              // Ring expansion burst
              for (let i = 0; i < 14; i++) {
                g.particles.push({
                  x: ringCenterX,
                  y: ringCenterY,
                  vx: Math.cos((i / 14) * Math.PI * 2) * 5,
                  vy: Math.sin((i / 14) * Math.PI * 2) * 5,
                  color: '#facc15',
                  size: 3,
                  alpha: 1,
                  life: 0,
                  maxLife: 25,
                });
              }
            }
            continue;
          }

          if (obs.type === 'wind_zone') continue; // harmless force field

          // Hazards: Laser gate, Cyber pillar, Patrol drone
          const boxLeft = obs.x;
          const boxRight = obs.x + obs.width;
          const boxTop = obs.y;
          const boxBottom = obs.y + obs.height;

          // AABB vs Pigeon Circle
          const closestX = Math.max(boxLeft, Math.min(pigeonX, boxRight));
          const closestY = Math.max(boxTop, Math.min(g.y, boxBottom));
          const distX = pigeonX - closestX;
          const distY = g.y - closestY;

          if (distX * distX + distY * distY < pR * pR) {
            // Collision hit!
            if (g.turboTime > 0) {
              // Turbo smashes obstacles!
              sounds.playLaserBuzz();
              obs.x = -999; // destroy obstacle
              for (let i = 0; i < 10; i++) {
                g.particles.push({
                  x: closestX,
                  y: closestY,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.5) * 6,
                  color: '#f43f5e',
                  size: 3,
                  alpha: 1,
                  life: 0,
                  maxLife: 20,
                });
              }
            } else if (g.shield) {
              // Shield breaks, gives brief invincibility
              sounds.playLaserBuzz();
              g.shield = false;
              setShieldActive(false);
              g.invincibleTimer = 1500;
              g.vy = -4;
              obs.x = -999;
            } else if (g.invincibleTimer <= 0) {
              gameOver();
              return;
            }
          }
        }

        // 11. Update Particles
        g.particles.forEach((p) => {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.life += dt;
          p.alpha = Math.max(0, 1 - p.life / p.maxLife);
        });
        g.particles = g.particles.filter((p) => p.life < p.maxLife);

        // Update React HUD state periodically
        setDistance(Math.floor(g.distance));
      }

      // 12. Canvas Rendering
      ctx.clearRect(0, 0, width, height);

      const currentBiome = g.generator.getCurrentBiome(g.distance);
      drawBiomeBackground(ctx, width, height, currentBiome, g.cameraX);
      drawObstacles(ctx, g.obstacles, g.cameraX);
      drawCoins(ctx, g.coins, g.cameraX);
      drawPowerups(ctx, g.powerups, g.cameraX);
      drawParticles(ctx, g.particles, g.cameraX);

      // Draw Local Pigeon
      const pigeonX = 120;
      drawPigeon(
        ctx,
        pigeonX,
        g.y,
        equippedSkin,
        g.vy,
        g.wingPhase,
        g.invincibleTimer > 0,
        g.shield,
        g.turboTime > 0
      );

      g.animationId = requestAnimationFrame(loop);
    };

    gameRef.current.animationId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(gameRef.current.animationId);
    };
  }, [equippedSkin, gameOver, biomeName]);

  // Handle ResizeObserver on container
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const resize = () => {
      if (canvasRef.current && container) {
        const rect = container.getBoundingClientRect();
        canvasRef.current.width = rect.width;
        canvasRef.current.height = Math.max(380, Math.min(560, window.innerHeight - 170));
        gameRef.current.canvasWidth = canvasRef.current.width;
        gameRef.current.canvasHeight = canvasRef.current.height;
      }
    };

    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    return () => ro.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full max-w-6xl mx-auto flex flex-col items-center select-none">
      {/* Game Canvas Container */}
      <div 
        id="flight-canvas-container"
        className="relative w-full overflow-hidden rounded-2xl border-2 border-cyan-500/50 bg-black shadow-2xl shadow-cyan-950/60 cursor-pointer"
        onClick={() => {
          if (gameState === 'playing') triggerFlap();
        }}
      >
        {/* Canvas */}
        <canvas ref={canvasRef} className="block w-full h-[400px] sm:h-[480px] touch-none" />

        {/* CRT Scanline Overlay */}
        <div className="absolute inset-0 crt-scanlines pointer-events-none"></div>

        {/* HUD Top Bar */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          {/* Distance & Biome HUD */}
          <div className="flex items-center gap-2 sm:gap-3 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-cyan-500/40 text-cyan-300 font-pixel text-xs shadow-lg">
            <div className="flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>{distance}m</span>
            </div>
            <span className="text-zinc-600">|</span>
            <div className="text-[10px] text-fuchsia-300 font-display font-bold">
              {biomeName.toUpperCase()}
            </div>
          </div>

          {/* Active Powerup Badges */}
          <div className="flex items-center gap-1.5">
            {shieldActive && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-950/80 border border-sky-400 text-sky-300 font-pixel text-[10px] animate-pulse">
                <Shield className="w-3 h-3 text-sky-400" />
                <span>SHIELD</span>
              </div>
            )}
            {magnetTimer > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-pink-950/80 border border-pink-400 text-pink-300 font-pixel text-[10px]">
                <Magnet className="w-3 h-3 text-pink-400" />
                <span>{magnetTimer}s</span>
              </div>
            )}
            {turboTimer > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-950/80 border border-amber-400 text-amber-300 font-pixel text-[10px] animate-bounce">
                <Zap className="w-3 h-3 text-amber-400" />
                <span>TURBO {turboTimer}s</span>
              </div>
            )}
          </div>

          {/* Coins & Multiplier */}
          <div className="flex items-center gap-2 sm:gap-3 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-amber-500/40 text-amber-300 font-pixel text-xs shadow-lg">
            {multiplier > 1 && (
              <span className="px-1.5 py-0.5 rounded bg-amber-500 text-zinc-950 font-bold text-[9px] animate-pulse">
                x{multiplier}
              </span>
            )}
            <div className="flex items-center gap-1">
              <span>🪙</span>
              <span>+{coinsCollectedThisRun}</span>
            </div>
          </div>
        </div>

        {/* Biome Announcement Banner */}
        {biomeBanner && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 px-6 py-2 rounded-xl bg-gradient-to-r from-fuchsia-950/90 via-purple-900/90 to-cyan-950/90 border-2 border-cyan-400/80 shadow-2xl shadow-cyan-500/30 text-cyan-200 font-pixel text-xs sm:text-sm tracking-wider animate-bounce pointer-events-none">
            ✨ {biomeBanner} ✨
          </div>
        )}

        {/* Initial Idle Screen */}
        {gameState === 'idle' && (
          <div className="absolute inset-0 bg-black/65 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-1 mb-4 shadow-xl shadow-cyan-500/30 animate-pulse">
              <div className="w-full h-full bg-zinc-950 rounded-xl flex items-center justify-center text-3xl">
                🕊️
              </div>
            </div>
            <h1 className="text-xl sm:text-3xl font-pixel text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-amber-300 mb-2">
              UNLIMITED NEON FLIGHT
            </h1>
            <p className="text-xs sm:text-sm font-display text-zinc-300 max-w-md mb-6">
              Navigate shifting saturated biomes, bypass moving laser gates, ride turbulent wind zones, and grab rare rainbow coins.
            </p>

            <button
              id="start-flight-btn"
              onClick={(e) => {
                e.stopPropagation();
                startGame();
              }}
              className="flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 text-zinc-950 font-pixel text-xs sm:text-sm font-bold shadow-lg shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>LAUNCH WINGS [SPACE]</span>
            </button>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-[11px] font-pixel text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-cyan-300">SPACE / CLICK</span>
                <span>Flap Wings</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-amber-400">🪙 x10</span>
                <span>Rainbow Coins</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-yellow-300">⭕ Rings</span>
                <span>Combo Impulse</span>
              </span>
            </div>
          </div>
        )}

        {/* Game Over Screen */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-fade-in">
            <div className="text-4xl mb-2">💥</div>
            <h2 className="text-xl sm:text-2xl font-pixel text-rose-500 mb-1">
              CIRCUIT BREACH
            </h2>
            <p className="text-xs text-zinc-400 font-display mb-4">
              Your cyber pigeon hit a high-energy hazard!
            </p>

            {isNewHighScore && (
              <div className="mb-4 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-yellow-400 text-yellow-300 font-pixel text-[10px] sm:text-xs animate-bounce">
                👑 NEW PERSONAL RECORD!
              </div>
            )}

            {/* Run Stats Bento Box */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 max-w-md w-full mb-6">
              <div className="bg-zinc-900/90 border border-cyan-900/60 rounded-xl p-3 text-center">
                <div className="text-[10px] font-pixel text-cyan-400 mb-1">DISTANCE</div>
                <div className="text-base sm:text-lg font-pixel text-white">{distance}m</div>
              </div>
              <div className="bg-zinc-900/90 border border-amber-900/60 rounded-xl p-3 text-center">
                <div className="text-[10px] font-pixel text-amber-400 mb-1">COINS</div>
                <div className="text-base sm:text-lg font-pixel text-amber-300">+{coinsCollectedThisRun}</div>
              </div>
              <div className="bg-zinc-900/90 border border-yellow-900/60 rounded-xl p-3 text-center">
                <div className="text-[10px] font-pixel text-yellow-400 mb-1">RINGS</div>
                <div className="text-base sm:text-lg font-pixel text-yellow-300">{ringsPassedThisRun}</div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                id="replay-flight-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  startGame();
                }}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 text-zinc-950 font-pixel text-xs font-bold shadow-lg shadow-cyan-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>PLAY AGAIN [SPACE]</span>
              </button>

              <button
                id="go-compete-gameover-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onGoToCompete();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-zinc-900 border border-fuchsia-500/50 hover:border-fuchsia-400 text-fuchsia-300 font-pixel text-xs transition-all cursor-pointer"
              >
                <Flag className="w-3.5 h-3.5 text-pink-400" />
                <span>LIVE RACES</span>
              </button>

              <button
                id="go-shop-gameover-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onGoToShop();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-zinc-900 border border-amber-500/50 hover:border-amber-400 text-amber-300 font-pixel text-xs transition-all cursor-pointer"
              >
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span>SKIN SHOP</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Controls Bar Below Canvas */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 mt-3 px-2 text-xs font-display text-zinc-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-zinc-300">Equipped Skin:</span>
          <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-cyan-300 font-pixel text-[10px]">
            {equippedSkin.name}
          </span>
          <button
            onClick={onGoToShop}
            className="text-[11px] text-amber-400 hover:text-amber-300 underline underline-offset-2 ml-1"
          >
            Change
          </button>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <span>Record: <strong className="text-white font-pixel">{profile.highScore}m</strong></span>
          <span>Career Coins: <strong className="text-amber-300 font-pixel">{profile.totalCoinsEarned.toLocaleString()}</strong></span>
        </div>
      </div>
    </div>
  );
};
