import React, { useState } from 'react';
import { X, User, Lock, Sparkles, CheckCircle2, Shield } from 'lucide-react';
import { UserProfile } from '../types';
import { sounds } from '../audio/chiptune';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onLoginSuccess: (token: string, newProfile: UserProfile) => void;
  onUpdateCallsign: (newName: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  profile,
  onLoginSuccess,
  onUpdateCallsign,
}) => {
  const [mode, setMode] = useState<'signin' | 'register' | 'guest_callsign'>(
    profile.isGuest ? 'register' : 'signin'
  );
  const [username, setUsername] = useState<string>(profile.username);
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'guest_callsign') {
      if (!username.trim() || username.trim().length < 2) {
        setError('Callsign must be at least 2 characters');
        return;
      }
      sounds.playCoin();
      onUpdateCallsign(username.trim());
      onClose();
      return;
    }

    if (!username.trim() || !password) {
      setError('Please fill in both callsign and password');
      return;
    }

    setLoading(true);
    const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          password,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Authentication error');
        setLoading(false);
        return;
      }

      sounds.playPowerup();
      // If registering from guest with progress, preserve guest coins and scores if higher
      const mergedProfile: UserProfile = {
        ...data.profile,
        coins: Math.max(data.profile.coins, profile.coins),
        highScore: Math.max(data.profile.highScore, profile.highScore),
        totalDistance: Math.max(data.profile.totalDistance, profile.totalDistance),
        totalCoinsEarned: Math.max(data.profile.totalCoinsEarned, profile.totalCoinsEarned),
        unlockedSkins: Array.from(new Set([...data.profile.unlockedSkins, ...profile.unlockedSkins])),
      };

      onLoginSuccess(data.token, mergedProfile);
      onClose();
    } catch (err: any) {
      setError('Failed to reach server. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-zinc-900 rounded-2xl border border-cyan-500/50 p-6 shadow-2xl shadow-cyan-950/60">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-0.5">
            <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center text-xl">
              🕊️
            </div>
          </div>
          <div>
            <h3 className="font-pixel text-sm text-white">PILOT IDENTITY &amp; CLOUD SYNC</h3>
            <p className="text-xs text-zinc-400 font-display">
              Carry your coin balances, high scores &amp; skins across any device.
            </p>
          </div>
        </div>

        {/* Auth Mode Selectors */}
        <div className="flex rounded-xl bg-zinc-950 p-1 mb-5 border border-zinc-800 text-xs font-display">
          <button
            type="button"
            onClick={() => {
              setError(null);
              setMode('signin');
            }}
            className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${
              mode === 'signin' ? 'bg-cyan-600 text-white shadow' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setError(null);
              setMode('register');
            }}
            className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${
              mode === 'register' ? 'bg-fuchsia-600 text-white shadow' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => {
              setError(null);
              setMode('guest_callsign');
            }}
            className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${
              mode === 'guest_callsign' ? 'bg-zinc-800 text-cyan-300 shadow' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Guest Tag
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs font-display">
              {error}
            </div>
          )}

          <div>
            <label className="block text-[10px] font-pixel text-zinc-400 mb-1">
              PILOT CALLSIGN
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                maxLength={20}
                required
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 pl-9 text-xs text-white focus:outline-none focus:border-cyan-500 font-display"
                placeholder="e.g. CyberWing_X"
              />
              <User className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
            </div>
          </div>

          {mode !== 'guest_callsign' && (
            <div>
              <label className="block text-[10px] font-pixel text-zinc-400 mb-1">
                SECRET KEY / PASSWORD
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={3}
                  required
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 pl-9 text-xs text-white focus:outline-none focus:border-cyan-500 font-display"
                  placeholder="••••••••"
                />
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
              </div>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 rounded-xl font-pixel text-xs font-bold transition-all shadow-lg cursor-pointer ${
                mode === 'signin'
                  ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-zinc-950 shadow-cyan-500/25 hover:from-cyan-400 hover:to-teal-400'
                  : mode === 'register'
                  ? 'bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white shadow-fuchsia-600/25 hover:from-fuchsia-500 hover:to-pink-500'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-white'
              }`}
            >
              {loading
                ? 'TRANSMITTING...'
                : mode === 'signin'
                ? 'LOG IN & SYNC CLOUD'
                : mode === 'register'
                ? 'CREATE CLOUD ACCOUNT'
                : 'SAVE GUEST CALLSIGN'}
            </button>
          </div>
        </form>

        <div className="mt-4 text-center text-[10px] text-zinc-500 font-display">
          🔒 Secure pilot identity data synced to cloud servers.
        </div>
      </div>
    </div>
  );
};
