import React from 'react';
import { Volume2, VolumeX, Coins, Trophy, User, Sparkles, Feather, Flag, CheckSquare } from 'lucide-react';
import { UserProfile } from '../types';
import { sounds } from '../audio/chiptune';

interface NavbarProps {
  activeTab: 'flight' | 'compete' | 'shop' | 'quests' | 'leaderboard';
  setActiveTab: (tab: 'flight' | 'compete' | 'shop' | 'quests' | 'leaderboard') => void;
  profile: UserProfile;
  isMuted: boolean;
  toggleMute: () => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  profile,
  isMuted,
  toggleMute,
  onOpenAuth,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-zinc-950/90 backdrop-blur-md border-b border-cyan-950/80 px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 sm:gap-4">
        
        {/* Brand */}
        <div 
          id="brand-logo"
          onClick={() => setActiveTab('flight')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-400/40 transition-all">
            <div className="w-full h-full bg-zinc-950 rounded-[7px] flex items-center justify-center">
              <span className="text-xl transform -rotate-12 group-hover:scale-110 transition-transform">🕊️</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-pixel text-[11px] sm:text-xs text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-yellow-400">
                NEON PIGEON
              </span>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-pixel bg-cyan-950/90 text-cyan-300 border border-cyan-700/60">
                ARCADE
              </span>
            </div>
            <div className="text-[10px] text-zinc-400 font-display flex items-center gap-1">
              <span>WINGS OF CYBER CITY</span>
              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center bg-zinc-900/90 p-1 rounded-xl border border-zinc-800 shadow-inner">
          <button
            id="nav-flight-btn"
            onClick={() => {
              sounds.playCoin();
              setActiveTab('flight');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
              activeTab === 'flight'
                ? 'bg-gradient-to-r from-cyan-600 to-cyan-500 text-white shadow-md shadow-cyan-500/25'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>Endless Flight</span>
          </button>

          <button
            id="nav-compete-btn"
            onClick={() => {
              sounds.playCoin();
              setActiveTab('compete');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-display font-semibold transition-all relative ${
              activeTab === 'compete'
                ? 'bg-gradient-to-r from-fuchsia-600 to-pink-500 text-white shadow-md shadow-fuchsia-500/25'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Flag className="w-3.5 h-3.5 text-pink-300" />
            <span>Live Compete</span>
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
          </button>

          <button
            id="nav-shop-btn"
            onClick={() => {
              sounds.playCoin();
              setActiveTab('shop');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
              activeTab === 'shop'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white shadow-md shadow-yellow-500/25'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Feather className="w-3.5 h-3.5 text-amber-300" />
            <span>Skins</span>
          </button>

          <button
            id="nav-quests-btn"
            onClick={() => {
              sounds.playCoin();
              setActiveTab('quests');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
              activeTab === 'quests'
                ? 'bg-gradient-to-r from-emerald-600 to-green-500 text-white shadow-md shadow-emerald-500/25'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5 text-emerald-300" />
            <span>Quests</span>
          </button>

          <button
            id="nav-leaderboard-btn"
            onClick={() => {
              sounds.playCoin();
              setActiveTab('leaderboard');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-display font-semibold transition-all ${
              activeTab === 'leaderboard'
                ? 'bg-gradient-to-r from-violet-600 to-purple-500 text-white shadow-md shadow-violet-500/25'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-violet-300" />
            <span>Rankings</span>
          </button>
        </nav>

        {/* Right Status Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* In-Game Coin Purse */}
          <div 
            id="coins-badge"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-950/40 border border-amber-500/40 text-amber-300 text-xs font-pixel shadow-sm shadow-amber-500/10"
            title="Real in-game collected coins"
          >
            <span className="inline-block animate-spin-slow">🪙</span>
            <span>{profile.coins.toLocaleString()}</span>
          </div>

          {/* Sound Mute Toggle */}
          <button
            id="audio-mute-toggle"
            onClick={toggleMute}
            className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-cyan-400 hover:border-cyan-700/60 transition-colors"
            title={isMuted ? 'Unmute Chiptune Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-zinc-500" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Account Profile / Cloud Sign-in Button */}
          <button
            id="account-auth-btn"
            onClick={onOpenAuth}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-display border transition-all ${
              profile.isGuest
                ? 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border-zinc-700/60'
                : 'bg-gradient-to-r from-indigo-950 to-purple-950 text-cyan-300 border-cyan-500/50 shadow-sm shadow-cyan-500/20'
            }`}
            title={profile.isGuest ? 'Sign In to save cloud progress' : 'Account active'}
          >
            <User className="w-3.5 h-3.5 text-cyan-400" />
            <span className="max-w-[80px] sm:max-w-[120px] truncate font-semibold">{profile.username}</span>
            {profile.isGuest ? (
              <span className="text-[9px] px-1 py-0.2 bg-zinc-800 text-zinc-400 rounded">Guest</span>
            ) : (
              <span className="text-[9px] px-1 py-0.2 bg-cyan-900/80 text-cyan-300 border border-cyan-700 rounded">Cloud</span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
