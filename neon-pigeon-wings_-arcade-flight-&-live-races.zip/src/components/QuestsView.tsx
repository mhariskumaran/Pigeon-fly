import React from 'react';
import confetti from 'canvas-confetti';
import { CheckSquare, Trophy, Coins, Award, CheckCircle2 } from 'lucide-react';
import { Quest, UserProfile } from '../types';
import { INITIAL_QUESTS } from '../game/constants';
import { sounds } from '../audio/chiptune';

interface QuestsViewProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
}

export const QuestsView: React.FC<QuestsViewProps> = ({ profile, onUpdateProfile }) => {
  // Compute progress for quests based on user profile stats
  const questsWithProgress: Quest[] = INITIAL_QUESTS.map((q) => {
    let currentProgress = 0;
    if (q.type === 'total_distance') {
      currentProgress = profile.totalDistance;
    } else if (q.type === 'races_won') {
      currentProgress = profile.racesWon;
    } else if (q.type === 'distance_single') {
      currentProgress = profile.highScore;
    } else if (q.type === 'coins_single') {
      currentProgress = Math.min(q.target, Math.floor(profile.highScore / 25));
    } else {
      currentProgress = Math.min(q.target, Math.floor(profile.totalDistance / 200));
    }

    const completed = currentProgress >= q.target;
    const claimed = profile.completedQuests.includes(q.id);

    return {
      ...q,
      progress: Math.min(q.target, currentProgress),
      completed,
      claimed,
    };
  });

  const handleClaim = (quest: Quest) => {
    sounds.playPowerup();
    confetti({
      particleCount: 80,
      spread: 70,
      colors: ['#22c55e', '#eab308', '#06b6d4'],
    });

    onUpdateProfile({
      coins: profile.coins + quest.rewardCoins,
      seasonPoints: profile.seasonPoints + quest.rewardSeasonPoints,
      completedQuests: [...profile.completedQuests, quest.id],
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-6">
      <div className="flex items-center justify-between p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CheckSquare className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base sm:text-xl font-pixel text-white">PILOT MISSIONS &amp; BOUNTIES</h2>
          </div>
          <p className="text-xs text-zinc-400 font-display">
            Complete flight objectives to claim bonus coins and season championship points.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-pixel text-zinc-400">COMPLETED</span>
          <div className="font-pixel text-emerald-400 text-lg">
            {questsWithProgress.filter((q) => q.claimed).length} / {questsWithProgress.length}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3.5">
        {questsWithProgress.map((quest) => {
          const percent = Math.min(100, Math.floor((quest.progress / quest.target) * 100));

          return (
            <div
              key={quest.id}
              className={`p-4 sm:p-5 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all ${
                quest.claimed
                  ? 'bg-zinc-900/40 border-zinc-800/80 opacity-70'
                  : quest.completed
                  ? 'bg-gradient-to-r from-emerald-950/40 to-zinc-900 border-emerald-500/60 shadow-lg shadow-emerald-500/10'
                  : 'bg-zinc-900/70 border-zinc-800'
              }`}
            >
              <div className="flex-1 w-full">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-pixel text-xs sm:text-sm text-white">{quest.title}</h4>
                  {quest.claimed ? (
                    <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[9px] font-pixel">
                      CLAIMED
                    </span>
                  ) : quest.completed ? (
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600 text-[9px] font-pixel animate-pulse">
                      READY TO CLAIM
                    </span>
                  ) : null}
                </div>

                <p className="text-xs text-zinc-400 font-display mb-3">{quest.description}</p>

                {/* Progress bar */}
                <div className="w-full max-w-md">
                  <div className="flex justify-between text-[10px] font-pixel text-zinc-400 mb-1">
                    <span>PROGRESS</span>
                    <span>{quest.progress} / {quest.target}</span>
                  </div>
                  <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        quest.completed ? 'bg-emerald-400' : 'bg-cyan-400'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Rewards & Claim Button */}
              <div className="flex sm:flex-col items-end justify-between w-full sm:w-auto gap-3 sm:gap-2">
                <div className="flex items-center gap-2 text-xs font-pixel text-amber-300">
                  <span>🪙 +{quest.rewardCoins}</span>
                  <span className="text-purple-300">+{quest.rewardSeasonPoints} PTS</span>
                </div>

                {quest.claimed ? (
                  <div className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-800 text-zinc-500 font-pixel text-[10px]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>DONE</span>
                  </div>
                ) : quest.completed ? (
                  <button
                    id={`claim-quest-${quest.id}`}
                    onClick={() => handleClaim(quest)}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-zinc-950 font-pixel text-xs font-bold shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                  >
                    CLAIM BOUNTY
                  </button>
                ) : (
                  <div className="px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500 font-pixel text-[10px]">
                    IN PROGRESS
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
